import type { CareerSpec } from "../sim/race";

export interface CareerEvent extends CareerSpec {
  id: string;
  name: string;
  subtitle: string;
  reward: number;
  timeOfDay: "day" | "sunset" | "night";
  rain: boolean;
}

export const CAREER: CareerEvent[] = [
  {
    id: "c1",
    name: "Harbor Sprint",
    subtitle: "Your first street race",
    distance: 2500,
    reward: 300,
    traffic: 0.2,
    obstacles: false,
    timeOfDay: "day",
    rain: false,
    opponents: [
      { name: "Rook", carId: "bmw-m4", top: 52 },
      { name: "Dash", carId: "nissan-gtr", top: 54 },
      { name: "Kiko", carId: "mercedes-amg-gt", top: 50 },
    ],
  },
  {
    id: "c2",
    name: "Sunset Boulevard",
    subtitle: "Golden hour duel",
    distance: 3000,
    reward: 420,
    traffic: 0.3,
    obstacles: false,
    timeOfDay: "sunset",
    rain: false,
    opponents: [
      { name: "Viper", carId: "nissan-gtr", top: 58 },
      { name: "Nova", carId: "porsche-911", top: 60 },
      { name: "Rook", carId: "bmw-m4", top: 56 },
    ],
  },
  {
    id: "c3",
    name: "Neon Downtown",
    subtitle: "City lights, heavy traffic",
    distance: 3500,
    reward: 560,
    traffic: 0.5,
    obstacles: true,
    timeOfDay: "night",
    rain: false,
    opponents: [
      { name: "Ghost", carId: "ferrari-488", top: 63 },
      { name: "Nova", carId: "porsche-911", top: 62 },
      { name: "Blaze", carId: "mercedes-amg-gt", top: 60 },
      { name: "Viper", carId: "nissan-gtr", top: 61 },
    ],
  },
  {
    id: "c4",
    name: "Storm Run",
    subtitle: "Wet asphalt, low grip",
    distance: 4000,
    reward: 700,
    traffic: 0.45,
    obstacles: true,
    timeOfDay: "day",
    rain: true,
    opponents: [
      { name: "Raven", carId: "mclaren-720s", top: 66 },
      { name: "Ghost", carId: "ferrari-488", top: 65 },
      { name: "Blaze", carId: "porsche-911", top: 64 },
    ],
  },
  {
    id: "c5",
    name: "Midnight Club",
    subtitle: "The crews come out",
    distance: 4500,
    reward: 900,
    traffic: 0.6,
    obstacles: true,
    timeOfDay: "night",
    rain: false,
    opponents: [
      { name: "Raven", carId: "mclaren-720s", top: 70 },
      { name: "Toro", carId: "lamborghini-aventador", top: 72 },
      { name: "Ghost", carId: "ferrari-488", top: 69 },
      { name: "Nova", carId: "porsche-911", top: 68 },
    ],
  },
  {
    id: "c6",
    name: "Rainlight Rally",
    subtitle: "Night storm showdown",
    distance: 5000,
    reward: 1150,
    traffic: 0.65,
    obstacles: true,
    timeOfDay: "night",
    rain: true,
    opponents: [
      { name: "Toro", carId: "lamborghini-aventador", top: 74 },
      { name: "Raven", carId: "mclaren-720s", top: 73 },
      { name: "Blaze", carId: "ferrari-488", top: 72 },
    ],
  },
  {
    id: "c7",
    name: "Coastal Highway",
    subtitle: "Flat out to the sea",
    distance: 5500,
    reward: 1400,
    traffic: 0.7,
    obstacles: true,
    timeOfDay: "sunset",
    rain: false,
    opponents: [
      { name: "Apex", carId: "bugatti-chiron", top: 78 },
      { name: "Toro", carId: "lamborghini-aventador", top: 77 },
      { name: "Raven", carId: "mclaren-720s", top: 76 },
      { name: "Ghost", carId: "ferrari-488", top: 75 },
    ],
  },
  {
    id: "c8",
    name: "Ultimate Final",
    subtitle: "Beat Apex for the crown",
    distance: 6500,
    reward: 2200,
    traffic: 0.8,
    obstacles: true,
    timeOfDay: "night",
    rain: true,
    opponents: [
      { name: "Apex", carId: "bugatti-chiron", top: 84 },
      { name: "Toro", carId: "lamborghini-aventador", top: 81 },
      { name: "Raven", carId: "mclaren-720s", top: 80 },
      { name: "Ghost", carId: "ferrari-488", top: 79 },
    ],
  },
];
