export type BodyKey = "supercar" | "gtcar";

export interface CarDef {
  id: string;
  name: string;
  brand: string;
  body: BodyKey;
  color: string;
  /** Non-uniform shape tweak on top of the normalized body (x width, y height, z length). */
  shape: [number, number, number];
  price: number;
  topSpeed: number; // km/h
  accel: number; // m/s^2
  handling: number;
  nitro: number; // seconds
  grip: number;
  tagline: string;
}

export const CARS: CarDef[] = [
  {
    id: "bmw-m4",
    name: "M4",
    brand: "BMW",
    body: "gtcar",
    color: "#1f6fe0",
    shape: [1, 1, 1],
    price: 0,
    topSpeed: 280,
    accel: 9.5,
    handling: 1.0,
    nitro: 3.5,
    grip: 1.0,
    tagline: "Twin-turbo street brawler",
  },
  {
    id: "nissan-gtr",
    name: "GT-R",
    brand: "Nissan",
    body: "gtcar",
    color: "#c9ced6",
    shape: [1.02, 0.96, 1],
    price: 600,
    topSpeed: 305,
    accel: 11,
    handling: 1.05,
    nitro: 4,
    grip: 1.12,
    tagline: "All-wheel-drive Godzilla",
  },
  {
    id: "mercedes-amg-gt",
    name: "AMG GT",
    brand: "Mercedes",
    body: "gtcar",
    color: "#4f8a3c",
    shape: [1, 0.92, 1.04],
    price: 1200,
    topSpeed: 315,
    accel: 10.8,
    handling: 1.02,
    nitro: 4,
    grip: 1.05,
    tagline: "Green Hell grand tourer",
  },
  {
    id: "porsche-911",
    name: "911 Turbo S",
    brand: "Porsche",
    body: "supercar",
    color: "#f2c230",
    shape: [0.97, 1.02, 0.95],
    price: 2000,
    topSpeed: 320,
    accel: 11.8,
    handling: 1.22,
    nitro: 4,
    grip: 1.15,
    tagline: "Precision on every corner",
  },
  {
    id: "ferrari-488",
    name: "488 GTB",
    brand: "Ferrari",
    body: "supercar",
    color: "#d3121c",
    shape: [1, 0.95, 1],
    price: 3500,
    topSpeed: 330,
    accel: 12.2,
    handling: 1.16,
    nitro: 4.5,
    grip: 1.1,
    tagline: "Rosso corsa thoroughbred",
  },
  {
    id: "mclaren-720s",
    name: "720S",
    brand: "McLaren",
    body: "supercar",
    color: "#ff7a1a",
    shape: [1.01, 0.92, 1.03],
    price: 5000,
    topSpeed: 341,
    accel: 12.9,
    handling: 1.2,
    nitro: 4.5,
    grip: 1.12,
    tagline: "Papaya-orange rocket",
  },
  {
    id: "lamborghini-aventador",
    name: "Aventador SVJ",
    brand: "Lamborghini",
    body: "supercar",
    color: "#8fdc2f",
    shape: [1.06, 0.87, 1.05],
    price: 7500,
    topSpeed: 350,
    accel: 13.6,
    handling: 1.1,
    nitro: 5,
    grip: 1.08,
    tagline: "V12 raging bull",
  },
  {
    id: "bugatti-chiron",
    name: "Chiron",
    brand: "Bugatti",
    body: "supercar",
    color: "#1d4fc4",
    shape: [1.05, 0.95, 1.06],
    price: 10000,
    topSpeed: 420,
    accel: 14.6,
    handling: 1.04,
    nitro: 5.5,
    grip: 1.1,
    tagline: "1500 hp hypercar king",
  },
];

export const DEFAULT_CAR_ID = "bmw-m4";

export function getCar(id: string): CarDef {
  return CARS.find((c) => c.id === id) ?? (CARS[0] as CarDef);
}

/** 0..100 bars for the garage UI. */
export function carBars(c: CarDef) {
  return {
    speed: Math.round(((c.topSpeed - 250) / 180) * 100),
    accel: Math.round(((c.accel - 8) / 7) * 100),
    handling: Math.round(((c.handling - 0.9) / 0.35) * 100),
    nitro: Math.round(((c.nitro - 3) / 3) * 100),
  };
}
