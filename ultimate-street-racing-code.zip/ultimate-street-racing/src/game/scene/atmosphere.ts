import * as THREE from "three";

interface Preset {
  skyTop: string;
  skyHorizon: string;
  fog: string;
  fogNear: number;
  fogFar: number;
  sun: string;
  sunI: number;
  sunDir: [number, number, number];
  hemiSky: string;
  hemiGround: string;
  hemiI: number;
  envI: number;
  night: number;
}

const PRESETS: Record<"day" | "sunset" | "night", Preset> = {
  day: {
    skyTop: "#2d6ccc",
    skyHorizon: "#c3dbf2",
    fog: "#b9cde0",
    fogNear: 70,
    fogFar: 430,
    sun: "#fff1dc",
    sunI: 2.8,
    sunDir: [0.45, 0.8, 0.4],
    hemiSky: "#d4e6ff",
    hemiGround: "#3d4248",
    hemiI: 0.95,
    envI: 0.9,
    night: 0,
  },
  sunset: {
    skyTop: "#2a2c70",
    skyHorizon: "#ff8a4a",
    fog: "#b8705a",
    fogNear: 55,
    fogFar: 370,
    sun: "#ffad6a",
    sunI: 2.1,
    sunDir: [0.25, 0.16, -0.95],
    hemiSky: "#ffb58c",
    hemiGround: "#2a2230",
    hemiI: 0.65,
    envI: 0.6,
    night: 0.4,
  },
  night: {
    skyTop: "#03040d",
    skyHorizon: "#1f1748",
    fog: "#0e0c22",
    fogNear: 35,
    fogFar: 280,
    sun: "#9db2ff",
    sunI: 0.45,
    sunDir: [-0.35, 0.7, -0.55],
    hemiSky: "#4a5aa0",
    hemiGround: "#0b0b14",
    hemiI: 0.4,
    envI: 0.3,
    night: 1,
  },
};

export interface Atmosphere {
  skyTop: THREE.Color;
  skyHorizon: THREE.Color;
  fog: THREE.Color;
  fogNear: number;
  fogFar: number;
  sun: THREE.Color;
  sunI: number;
  sunDir: THREE.Vector3;
  hemiSky: THREE.Color;
  hemiGround: THREE.Color;
  hemiI: number;
  envI: number;
  night: number;
  rain: number;
  lightning: number;
}

export function createAtmosphere(): Atmosphere {
  return {
    skyTop: new THREE.Color(),
    skyHorizon: new THREE.Color(),
    fog: new THREE.Color(),
    fogNear: 60,
    fogFar: 400,
    sun: new THREE.Color(),
    sunI: 1,
    sunDir: new THREE.Vector3(0, 1, 0),
    hemiSky: new THREE.Color(),
    hemiGround: new THREE.Color(),
    hemiI: 1,
    envI: 1,
    night: 0,
    rain: 0,
    lightning: 0,
  };
}

// Dynamic cycle keyframes (seconds, preset).
const CYCLE: [number, keyof typeof PRESETS][] = [
  [0, "day"],
  [55, "day"],
  [72, "sunset"],
  [90, "sunset"],
  [108, "night"],
  [170, "night"],
  [185, "sunset"],
  [192, "sunset"],
  [210, "day"],
];
const CYCLE_LEN = 210;

const tmpA = new THREE.Color();
const tmpB = new THREE.Color();
const RAIN_DAY = new THREE.Color("#69707e");
const RAIN_NIGHT = new THREE.Color("#14161f");

function lerpPreset(atm: Atmosphere, a: Preset, b: Preset, f: number) {
  const lc = (out: THREE.Color, x: string, y: string) => out.copy(tmpA.set(x)).lerp(tmpB.set(y), f);
  lc(atm.skyTop, a.skyTop, b.skyTop);
  lc(atm.skyHorizon, a.skyHorizon, b.skyHorizon);
  lc(atm.fog, a.fog, b.fog);
  lc(atm.sun, a.sun, b.sun);
  lc(atm.hemiSky, a.hemiSky, b.hemiSky);
  lc(atm.hemiGround, a.hemiGround, b.hemiGround);
  const l = (x: number, y: number) => x + (y - x) * f;
  atm.fogNear = l(a.fogNear, b.fogNear);
  atm.fogFar = l(a.fogFar, b.fogFar);
  atm.sunI = l(a.sunI, b.sunI);
  atm.hemiI = l(a.hemiI, b.hemiI);
  atm.envI = l(a.envI, b.envI);
  atm.night = l(a.night, b.night);
  atm.sunDir.set(l(a.sunDir[0], b.sunDir[0]), l(a.sunDir[1], b.sunDir[1]), l(a.sunDir[2], b.sunDir[2])).normalize();
}

export interface AtmosphereOptions {
  timeOfDay: "day" | "sunset" | "night" | "dynamic";
  weather: "clear" | "rain" | "dynamic";
}

export function updateAtmosphere(atm: Atmosphere, o: AtmosphereOptions, t: number, dt: number, rng: () => number) {
  if (o.timeOfDay === "dynamic") {
    const ct = t % CYCLE_LEN;
    let i = 0;
    while (i < CYCLE.length - 2 && (CYCLE[i + 1]?.[0] ?? 0) <= ct) i++;
    const k0 = CYCLE[i] ?? CYCLE[0]!;
    const k1 = CYCLE[i + 1] ?? CYCLE[0]!;
    const span = Math.max(1e-3, k1[0] - k0[0]);
    const f = THREE.MathUtils.smoothstep((ct - k0[0]) / span, 0, 1);
    lerpPreset(atm, PRESETS[k0[1]], PRESETS[k1[1]], f);
  } else {
    const p = PRESETS[o.timeOfDay];
    lerpPreset(atm, p, p, 0);
  }

  const target = o.weather === "rain" ? 1 : o.weather === "clear" ? 0 : (t + 40) % 130 > 85 ? 1 : 0;
  if (dt === 0) atm.rain = target;
  atm.rain += Math.sign(target - atm.rain) * Math.min(Math.abs(target - atm.rain), dt * 0.18);

  const r = atm.rain;
  if (r > 0) {
    tmpA.copy(RAIN_DAY).lerp(RAIN_NIGHT, atm.night);
    atm.fog.lerp(tmpA, r * 0.65);
    atm.skyTop.lerp(tmpA, r * 0.7);
    atm.skyHorizon.lerp(tmpA, r * 0.6);
    atm.fogFar *= 1 - 0.42 * r;
    atm.fogNear *= 1 - 0.5 * r;
    atm.sunI *= 1 - 0.6 * r;
    atm.envI *= 1 - 0.3 * r;
  }
  // Lightning on stormy nights.
  atm.lightning = Math.max(0, atm.lightning - dt * 3);
  if (r > 0.7 && atm.night > 0.5 && rng() < dt * 0.06) atm.lightning = 1;
}
