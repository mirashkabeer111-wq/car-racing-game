import * as THREE from "three";
import { useGLTF } from "@react-three/drei";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import supercarModel from "@/assets/models/supercar.glb.asset.json";
import gtcarModel from "@/assets/models/gtcar.glb.asset.json";
import sedanModel from "@/assets/models/sedan.glb.asset.json";
import suvModel from "@/assets/models/suv.glb.asset.json";
import taxiModel from "@/assets/models/taxi.glb.asset.json";
import vanModel from "@/assets/models/van.glb.asset.json";
import truckModel from "@/assets/models/truck.glb.asset.json";
import policeModel from "@/assets/models/police.glb.asset.json";
import deliveryModel from "@/assets/models/delivery.glb.asset.json";
import coneModel from "@/assets/models/cone.glb.asset.json";
import boxModel from "@/assets/models/box.glb.asset.json";
import type { BodyKey, CarDef } from "../data/cars";

export const BODY_URLS: Record<BodyKey, string> = { supercar: supercarModel.url, gtcar: gtcarModel.url };
export const TRAFFIC_URLS = [
  sedanModel.url,
  suvModel.url,
  taxiModel.url,
  vanModel.url,
  truckModel.url,
  policeModel.url,
  deliveryModel.url,
];
export const PROP_URLS = { cone: coneModel.url, box: boxModel.url };

export function preloadModels() {
  for (const u of [...Object.values(BODY_URLS), ...TRAFFIC_URLS, ...Object.values(PROP_URLS)]) useGLTF.preload(u);
}

export const CAR_LENGTH = 4.45;

export interface CarHandle {
  wheels: THREE.Object3D[];
  front: THREE.Object3D[];
  head: THREE.MeshStandardMaterial[];
  tail: THREE.MeshStandardMaterial[];
  spin: number;
}

function paintHueSwap(mat: THREE.MeshStandardMaterial, color: THREE.Color) {
  const uniforms = { uPaint: { value: color } };
  mat.onBeforeCompile = (shader) => {
    shader.uniforms["uPaint"] = uniforms.uPaint;
    shader.fragmentShader = shader.fragmentShader
      .replace("#include <common>", "#include <common>\nuniform vec3 uPaint;")
      .replace(
        "#include <map_fragment>",
        `#ifdef USE_MAP
          vec4 sampledDiffuseColor = texture2D( map, vMapUv );
          vec3 cc = sampledDiffuseColor.rgb;
          float mx = max(cc.r, max(cc.g, cc.b));
          float mn = min(cc.r, min(cc.g, cc.b));
          float sat = (mx - mn) / max(mx, 1e-4);
          float isPaint = step(0.55, sat) * step(cc.b * 2.5, cc.g) * step(0.3, cc.g / max(cc.r, 1e-4)) * step(cc.g, cc.r * 1.2);
          vec3 painted = uPaint * clamp(mx / 0.6, 0.25, 1.4);
          sampledDiffuseColor.rgb = mix(cc, painted, isPaint);
          diffuseColor *= sampledDiffuseColor;
        #endif`,
      );
  };
  mat.customProgramCacheKey = () => "paint-hue-swap";
}

/** Clone a body GLB, repaint it, add wheel pivots, and normalize to CAR_LENGTH facing -Z. */
export function buildCar(source: THREE.Object3D, car: CarDef, premium: boolean) {
  const clone = source.clone(true);
  const paint = new THREE.Color(car.color);
  const head: THREE.MeshStandardMaterial[] = [];
  const tail: THREE.MeshStandardMaterial[] = [];
  const matCache = new Map<THREE.Material, THREE.Material>();

  clone.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    const swap = (m: THREE.Material): THREE.Material => {
      const cached = matCache.get(m);
      if (cached) return cached;
      const src = m as THREE.MeshStandardMaterial;
      let out: THREE.MeshStandardMaterial;
      const name = src.name;
      if (name === "White") {
        out = premium
          ? new THREE.MeshPhysicalMaterial({ color: paint, metalness: 0.55, roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.08 })
          : new THREE.MeshStandardMaterial({ color: paint, metalness: 0.55, roughness: 0.3 });
      } else {
        out = src.clone();
        if (name === "Atlas") {
          out.metalness = 0.45;
          out.roughness = 0.38;
          paintHueSwap(out, paint);
        } else if (name === "Windows") {
          out.metalness = 0.9;
          out.roughness = 0.08;
        } else if (name === "Headlights") {
          out.emissive = new THREE.Color("#fff4dc");
          out.emissiveIntensity = 0.4;
          head.push(out);
        } else if (name === "TailLights" || name === "BrakeLight") {
          out.color = new THREE.Color("#b3121a");
          out.emissive = new THREE.Color("#ff2030");
          out.emissiveIntensity = 0.6;
          tail.push(out);
        }
      }
      out.name = name;
      matCache.set(m, out);
      return out;
    };
    mesh.material = Array.isArray(mesh.material) ? mesh.material.map(swap) : swap(mesh.material);
  });

  // Wheel pivots at each wheel's center so spinning works regardless of the file's origins.
  clone.updateMatrixWorld(true);
  const wheels: THREE.Object3D[] = [];
  const front: THREE.Object3D[] = [];
  const wheelMeshes: THREE.Object3D[] = [];
  clone.traverse((o) => {
    if ((o as THREE.Mesh).isMesh && /wheel/i.test(o.name + (o.parent?.name ?? ""))) wheelMeshes.push(o);
  });
  for (const m of wheelMeshes) {
    const parent = m.parent;
    if (!parent) continue;
    const isFront = /front/i.test(m.name + parent.name);
    const box = new THREE.Box3().setFromObject(m);
    const center = box.getCenter(new THREE.Vector3());
    const pivot = new THREE.Group();
    pivot.rotation.order = "YXZ";
    parent.worldToLocal(center);
    pivot.position.copy(center);
    parent.add(pivot);
    pivot.updateMatrixWorld(true);
    pivot.attach(m);
    wheels.push(pivot);
    if (isFront) front.push(pivot);
  }
  // A wheel mesh nested under a named node: check the original names too.
  if (front.length === 0) {
    for (const w of wheels) {
      const child = w.children[0];
      if (child && /front/i.test(child.name)) front.push(w);
    }
  }

  // Normalize.
  clone.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(clone);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const s = CAR_LENGTH / Math.max(size.z, 1e-3);
  const inner = new THREE.Group();
  inner.add(clone);
  clone.position.set(-center.x, -box.min.y, -center.z);
  inner.scale.setScalar(s);
  const outer = new THREE.Group();
  outer.add(inner);
  outer.rotation.y = Math.PI; // models face +Z; the game drives toward -Z
  outer.scale.set(car.shape[0], car.shape[1], car.shape[2]);
  const root = new THREE.Group();
  root.add(outer);

  const handle: CarHandle = { wheels, front, head, tail, spin: 0 };
  return { root, handle };
}

export function updateCarHandle(h: CarHandle, v: number, dt: number, steer: number, braking: boolean, night: number) {
  h.spin += (v * dt) / 0.36;
  for (const w of h.wheels) w.rotation.x = h.spin;
  for (const f of h.front) f.rotation.y = -steer * 0.35;
  for (const m of h.head) m.emissiveIntensity = 0.4 + night * 3.2;
  for (const m of h.tail) m.emissiveIntensity = braking ? 4 : 0.5 + night * 1.6;
}

/** Merge a GLB into one geometry (shared atlas material) for instanced traffic/props. */
export function mergeScene(scene: THREE.Object3D, scale: number, rotateY: number) {
  scene.updateMatrixWorld(true);
  const geos: THREE.BufferGeometry[] = [];
  let material: THREE.Material | null = null;
  scene.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const g = mesh.geometry.clone();
    g.applyMatrix4(mesh.matrixWorld);
    for (const key of Object.keys(g.attributes)) {
      if (!["position", "normal", "uv"].includes(key)) g.deleteAttribute(key);
    }
    geos.push(g);
    if (!material) material = Array.isArray(mesh.material) ? (mesh.material[0] ?? null) : mesh.material;
  });
  const anyIndexed = geos.some((g) => g.index);
  const allIndexed = geos.every((g) => g.index);
  const list = anyIndexed && !allIndexed ? geos.map((g) => (g.index ? g.toNonIndexed() : g)) : geos;
  const merged = mergeGeometries(list, false) ?? list[0] ?? new THREE.BoxGeometry(1, 1, 1);
  merged.rotateY(rotateY);
  merged.scale(scale, scale, scale);
  merged.computeBoundingBox();
  const minY = merged.boundingBox?.min.y ?? 0;
  merged.translate(0, -minY, 0);
  merged.computeBoundingSphere();
  return { geometry: merged, material: (material ?? new THREE.MeshStandardMaterial()) as THREE.Material };
}
