import { useFrame, useThree } from "@react-three/fiber";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { mulberry32 } from "../sim/rng";
import { RAIL_X } from "../sim/constants";
import { scrollAhead, useRace } from "./raceContext";
import {
  makeGlowTexture,
  makeGroundTexture,
  makeRoadTexture,
  makeSignTexture,
  makeWindowTextures,
  makeCheckerTexture,
} from "./textures";

const ROAD_LEN = 800;
const tmpM = new THREE.Matrix4();
const tmpQ = new THREE.Quaternion();
const tmpS = new THREE.Vector3();
const tmpP = new THREE.Vector3();
const tmpE = new THREE.Euler();
const ZERO = new THREE.Matrix4().makeScale(0, 0, 0);

function compose(x: number, y: number, z: number, ry: number, sx: number, sy: number, sz: number) {
  tmpE.set(0, ry, 0);
  tmpQ.setFromEuler(tmpE);
  tmpP.set(x, y, z);
  tmpS.set(sx, sy, sz);
  return tmpM.compose(tmpP, tmpQ, tmpS);
}

export function Road() {
  const { sim, atm } = useRace();
  const gl = useThree((s) => s.gl);
  const roadTex = useMemo(() => {
    const t = makeRoadTexture();
    t.repeat.set(1, ROAD_LEN / 12);
    t.anisotropy = Math.min(8, gl.capabilities.getMaxAnisotropy());
    return t;
  }, [gl]);
  const groundTex = useMemo(() => {
    const t = makeGroundTexture();
    t.repeat.set(600 / 10, ROAD_LEN / 10);
    return t;
  }, []);
  const roadMat = useRef<THREE.MeshStandardMaterial>(null);
  useFrame(() => {
    const s = sim.player.s;
    roadTex.offset.y = (s / 12) % 1;
    groundTex.offset.y = (s / 10) % 1;
    const m = roadMat.current;
    if (m) {
      m.roughness = 0.88 - 0.62 * atm.rain;
      m.metalness = 0.05 + 0.3 * atm.rain;
      m.color.setScalar(1 - 0.35 * atm.rain);
    }
  });
  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0, -ROAD_LEN / 2 + 60]} receiveShadow>
        <planeGeometry args={[19, ROAD_LEN]} />
        <meshStandardMaterial ref={roadMat} map={roadTex} roughness={0.88} envMapIntensity={1.4} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, -0.04, -ROAD_LEN / 2 + 60]}>
        <planeGeometry args={[600, ROAD_LEN]} />
        <meshStandardMaterial map={groundTex} roughness={1} />
      </mesh>
      {/* Guard rails: continuous beams. */}
      {[-1, 1].map((side) => (
        <mesh key={side} position={[side * RAIL_X, 0.62, -ROAD_LEN / 2 + 60]}>
          <boxGeometry args={[0.14, 0.32, ROAD_LEN]} />
          <meshStandardMaterial color="#9aa2ae" metalness={0.85} roughness={0.3} />
        </mesh>
      ))}
      <RailPosts />
    </group>
  );
}

function RailPosts() {
  const { sim } = useRace();
  const ref = useRef<THREE.InstancedMesh>(null);
  const SPACING = 4;
  const PER_SIDE = 90;
  const LOOP = SPACING * PER_SIDE;
  useFrame(() => {
    const m = ref.current;
    if (!m) return;
    const s = sim.player.s;
    let i = 0;
    for (const side of [-1, 1]) {
      for (let k = 0; k < PER_SIDE; k++) {
        const z = -scrollAhead(k * SPACING, s, LOOP, 30);
        m.setMatrixAt(i++, compose(side * (RAIL_X + 0.1), 0.4, z, 0, 1, 1, 1));
      }
    }
    m.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, PER_SIDE * 2]} frustumCulled={false}>
      <boxGeometry args={[0.12, 0.8, 0.12]} />
      <meshStandardMaterial color="#6d737c" metalness={0.7} roughness={0.4} />
    </instancedMesh>
  );
}

export function StreetLamps() {
  const { sim, atm } = useRace();
  const poles = useRef<THREE.InstancedMesh>(null);
  const heads = useRef<THREE.InstancedMesh>(null);
  const pools = useRef<THREE.InstancedMesh>(null);
  const headMat = useRef<THREE.MeshBasicMaterial>(null);
  const poolMat = useRef<THREE.MeshBasicMaterial>(null);
  const SPACING = 50;
  const PER_SIDE = 10;
  const LOOP = SPACING * PER_SIDE;
  const poleGeo = useMemo(() => {
    const pole = new THREE.CylinderGeometry(0.1, 0.14, 9, 8).translate(0, 4.5, 0);
    const arm = new THREE.BoxGeometry(2.7, 0.12, 0.12).translate(-1.3, 8.9, 0);
    return mergeGeometries([pole.toNonIndexed(), arm.toNonIndexed()]) ?? pole;
  }, []);
  const glow = useMemo(() => makeGlowTexture(), []);
  const headBase = useMemo(() => new THREE.Color("#ffe2b0"), []);
  useFrame(() => {
    const s = sim.player.s;
    let i = 0;
    for (const side of [-1, 1]) {
      for (let k = 0; k < PER_SIDE; k++) {
        const z = -scrollAhead(k * SPACING + (side > 0 ? SPACING / 2 : 0), s, LOOP, 40);
        const x = side * (RAIL_X + 0.9);
        poles.current?.setMatrixAt(i, compose(x, 0, z, side > 0 ? 0 : Math.PI, 1, 1, 1));
        heads.current?.setMatrixAt(i, compose(x - side * 2.5, 8.82, z, 0, 1, 1, 1));
        pools.current?.setMatrixAt(i, compose(x - side * 2.8, 0.03, z, 0, 1, 1, 1));
        i++;
      }
    }
    for (const r of [poles, heads, pools]) if (r.current) r.current.instanceMatrix.needsUpdate = true;
    if (headMat.current) headMat.current.color.copy(headBase).multiplyScalar(0.5 + atm.night * 2.5);
    if (poolMat.current) poolMat.current.opacity = atm.night * 0.42;
  });
  return (
    <group>
      <instancedMesh ref={poles} args={[poleGeo, undefined, PER_SIDE * 2]} frustumCulled={false} castShadow>
        <meshStandardMaterial color="#555b66" metalness={0.6} roughness={0.45} />
      </instancedMesh>
      <instancedMesh ref={heads} args={[undefined, undefined, PER_SIDE * 2]} frustumCulled={false}>
        <boxGeometry args={[1.1, 0.16, 0.45]} />
        <meshBasicMaterial ref={headMat} toneMapped={false} />
      </instancedMesh>
      <instancedMesh ref={pools} args={[undefined, undefined, PER_SIDE * 2]} frustumCulled={false}>
        <planeGeometry args={[11, 11]} />
        <meshBasicMaterial
          ref={poolMat}
          map={glow}
          color="#ffcf8a"
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          side={THREE.DoubleSide}
          opacity={0}
        />
      </instancedMesh>
    </group>
  );
}

// Hoisted so the planes lie flat.
function FlatPools({ children }: { children: React.ReactNode }) {
  return <group>{children}</group>;
}
void FlatPools;

interface BuildingInfo {
  base: number;
  x: number;
  w: number;
  d: number;
  h: number;
  side: number;
  neon: boolean;
  neonOff: number;
}

export function City() {
  const { sim, atm, quality } = useRace();
  const buildings = useRef<THREE.InstancedMesh>(null);
  const neon = useRef<THREE.InstancedMesh>(null);
  const bMat = useRef<THREE.MeshStandardMaterial>(null);
  const nMat = useRef<THREE.MeshBasicMaterial>(null);
  const PER_SIDE = quality === "low" ? 16 : 24;
  const LOOP = 600;
  const tex = useMemo(() => makeWindowTextures(), []);
  const geo = useMemo(() => new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), []);
  const infos = useMemo(() => {
    const rng = mulberry32(7);
    const out: BuildingInfo[] = [];
    for (const side of [-1, 1]) {
      for (let k = 0; k < PER_SIDE; k++) {
        const far = rng();
        out.push({
          base: (k * LOOP) / PER_SIDE + rng() * 8,
          x: side * (30 + far * 50),
          w: 12 + rng() * 14,
          d: 12 + rng() * 12,
          h: 14 + rng() * 30 + far * 45,
          side,
          neon: rng() < 0.45,
          neonOff: rng() - 0.5,
        });
      }
    }
    return out;
  }, [PER_SIDE]);
  useLayoutEffect(() => {
    const palette = ["#9aa3b5", "#7d8597", "#b8bcc8", "#6c7487", "#8f8aa8", "#a49a92"].map((c) => new THREE.Color(c));
    const neonCols = [new THREE.Color("#33c4ff"), new THREE.Color("#b04dff"), new THREE.Color("#ff3fb4")];
    infos.forEach((b, i) => {
      buildings.current?.setColorAt(i, palette[i % palette.length] ?? palette[0]!);
      neon.current?.setColorAt(i, neonCols[i % neonCols.length] ?? neonCols[0]!);
    });
    if (buildings.current?.instanceColor) buildings.current.instanceColor.needsUpdate = true;
    if (neon.current?.instanceColor) neon.current.instanceColor.needsUpdate = true;
  }, [infos]);
  useFrame(() => {
    const s = sim.player.s;
    infos.forEach((b, i) => {
      const z = -scrollAhead(b.base, s, LOOP, 60);
      buildings.current?.setMatrixAt(i, compose(b.x, 0, z, 0, b.w, b.h, b.d));
      if (b.neon) {
        neon.current?.setMatrixAt(
          i,
          compose(b.x - b.side * (b.w / 2 + 0.25), b.h * 0.12, z + b.neonOff * b.d * 0.6, 0, 0.5, b.h * 0.8, 0.5),
        );
      } else neon.current?.setMatrixAt(i, ZERO);
    });
    if (buildings.current) buildings.current.instanceMatrix.needsUpdate = true;
    if (neon.current) neon.current.instanceMatrix.needsUpdate = true;
    if (bMat.current) bMat.current.emissiveIntensity = 0.06 + atm.night * 1.5;
    if (nMat.current) nMat.current.color.setScalar(0.55 + atm.night * 1.6);
  });
  return (
    <group>
      <instancedMesh ref={buildings} args={[geo, undefined, infos.length]} frustumCulled={false}>
        <meshStandardMaterial
          ref={bMat}
          map={tex.map}
          emissiveMap={tex.emissive}
          emissive="#ffffff"
          roughness={0.6}
          metalness={0.2}
        />
      </instancedMesh>
      <instancedMesh ref={neon} args={[geo, undefined, infos.length]} frustumCulled={false}>
        <meshBasicMaterial ref={nMat} toneMapped={false} />
      </instancedMesh>
    </group>
  );
}

export function Trees() {
  const { sim, quality } = useRace();
  const trunks = useRef<THREE.InstancedMesh>(null);
  const crowns = useRef<THREE.InstancedMesh>(null);
  const PER_SIDE = quality === "low" ? 16 : 28;
  const LOOP = 420;
  const infos = useMemo(() => {
    const rng = mulberry32(11);
    const out: { base: number; x: number; sc: number }[] = [];
    for (const side of [-1, 1])
      for (let k = 0; k < PER_SIDE; k++)
        out.push({ base: (k * LOOP) / PER_SIDE + rng() * 6, x: side * (12.5 + rng() * 10), sc: 0.8 + rng() * 0.7 });
    return out;
  }, [PER_SIDE]);
  const crownGeo = useMemo(() => new THREE.IcosahedronGeometry(1.8, 0).scale(1, 1.35, 1).translate(0, 3.6, 0), []);
  const trunkGeo = useMemo(() => new THREE.CylinderGeometry(0.16, 0.24, 2.4, 6).translate(0, 1.2, 0), []);
  useFrame(() => {
    const s = sim.player.s;
    infos.forEach((t, i) => {
      const z = -scrollAhead(t.base, s, LOOP, 40);
      const m = compose(t.x, 0, z, t.base, t.sc, t.sc, t.sc);
      trunks.current?.setMatrixAt(i, m);
      crowns.current?.setMatrixAt(i, m);
    });
    if (trunks.current) trunks.current.instanceMatrix.needsUpdate = true;
    if (crowns.current) crowns.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <group>
      <instancedMesh ref={trunks} args={[trunkGeo, undefined, infos.length]} frustumCulled={false}>
        <meshStandardMaterial color="#4a3628" roughness={1} />
      </instancedMesh>
      <instancedMesh ref={crowns} args={[crownGeo, undefined, infos.length]} frustumCulled={false}>
        <meshStandardMaterial color="#2f5a3a" roughness={0.9} flatShading />
      </instancedMesh>
    </group>
  );
}

export function Gantries() {
  const { sim, atm } = useRace();
  const group = useRef<THREE.Group>(null);
  const signMat = useRef<THREE.MeshBasicMaterial>(null);
  const tex = useMemo(() => makeSignTexture("ULTIMATE STREET RACING", "NEON CITY EXPRESSWAY  ·  NO SPEED LIMIT"), []);
  useFrame(() => {
    if (group.current) group.current.position.z = -scrollAhead(380, sim.player.s, 700, 40);
    if (signMat.current) signMat.current.color.setScalar(0.75 + atm.night * 0.9);
  });
  return (
    <group ref={group}>
      {[-1, 1].map((side) => (
        <mesh key={side} position={[side * 10.2, 4, 0]}>
          <boxGeometry args={[0.5, 8, 0.5]} />
          <meshStandardMaterial color="#3b404a" metalness={0.7} roughness={0.4} />
        </mesh>
      ))}
      <mesh position={[0, 7.7, 0]}>
        <boxGeometry args={[21, 0.7, 0.7]} />
        <meshStandardMaterial color="#3b404a" metalness={0.7} roughness={0.4} />
      </mesh>
      <mesh position={[0, 6.2, 0.4]}>
        <planeGeometry args={[13, 2]} />
        <meshBasicMaterial ref={signMat} map={tex} toneMapped={false} />
      </mesh>
    </group>
  );
}

/** Start line, time-trial checkpoints and the finish arch. */
export function RaceArches() {
  const { sim } = useRace();
  const arch = useRef<THREE.Group>(null);
  const banner = useRef<THREE.MeshBasicMaterial>(null);
  const checker = useMemo(() => makeCheckerTexture(), []);
  const neonTex = useMemo(() => makeSignTexture("CHECKPOINT", "+ TIME BONUS"), []);
  const finishTex = useMemo(() => makeSignTexture("FINISH", "ULTIMATE STREET RACING"), []);
  const startTex = useMemo(() => makeSignTexture("START", "GET READY"), []);
  const line = useRef<THREE.Mesh>(null);
  useFrame(() => {
    const g = arch.current;
    if (!g) return;
    const st = sim;
    const p = st.player;
    let target: number | null = null;
    let tex = startTex;
    if (p.s < 30) {
      target = 6;
    } else if (st.config.mode === "timetrial") {
      const next = (st.checkpointIndex + 1) * 1000;
      target = Math.min(next, st.finishDistance);
      tex = target >= st.finishDistance ? finishTex : neonTex;
    } else if (st.config.mode === "career") {
      target = st.finishDistance;
      tex = finishTex;
    }
    if (target === null || target - p.s > 650 || target - p.s < -40) {
      g.visible = false;
      return;
    }
    g.visible = true;
    g.position.z = -(target - p.s);
    if (banner.current && banner.current.map !== tex) {
      banner.current.map = tex;
      banner.current.needsUpdate = true;
    }
    if (line.current) line.current.visible = tex === finishTex || tex === startTex;
  });
  return (
    <group ref={arch}>
      {[-1, 1].map((side) => (
        <mesh key={side} position={[side * 9.6, 3.5, 0]}>
          <boxGeometry args={[0.6, 7, 0.6]} />
          <meshBasicMaterial color={side < 0 ? "#3cc8ff" : "#b44dff"} toneMapped={false} />
        </mesh>
      ))}
      <mesh position={[0, 7.2, 0]}>
        <planeGeometry args={[19.8, 2.4]} />
        <meshBasicMaterial ref={banner} map={startTex} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      <mesh ref={line} rotation-x={-Math.PI / 2} position={[0, 0.02, 0]}>
        <planeGeometry args={[16, 2]} />
        <meshBasicMaterial map={checker} />
      </mesh>
    </group>
  );
}

const skyVert = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  gl_Position = p.xyww;
}`;
const skyFrag = /* glsl */ `
uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uSunDir; uniform vec3 uSun; uniform float uNight; uniform float uFlash;
varying vec3 vDir;
void main() {
  vec3 d = normalize(vDir);
  float h = clamp(d.y * 1.4 + 0.05, 0.0, 1.0);
  vec3 col = mix(uHorizon, uTop, pow(h, 0.6));
  float sd = max(dot(d, normalize(uSunDir)), 0.0);
  float disc = smoothstep(0.9993, 0.9997, sd);
  col += uSun * (disc * mix(3.0, 1.2, uNight) + pow(sd, 10.0) * 0.35 * (1.0 - uNight * 0.6));
  col += vec3(0.7, 0.75, 1.0) * uFlash * 0.8;
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

export function Sky() {
  const { atm } = useRace();
  const mesh = useRef<THREE.Mesh>(null);
  const stars = useRef<THREE.Points>(null);
  const uniforms = useMemo(
    () => ({
      uTop: { value: new THREE.Color() },
      uHorizon: { value: new THREE.Color() },
      uSunDir: { value: new THREE.Vector3(0, 1, 0) },
      uSun: { value: new THREE.Color() },
      uNight: { value: 0 },
      uFlash: { value: 0 },
    }),
    [],
  );
  const starGeo = useMemo(() => {
    const rng = mulberry32(3);
    const n = 900;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const th = rng() * Math.PI * 2;
      const y = 0.08 + rng() * 0.92;
      const r = Math.sqrt(1 - y * y);
      pos.set([Math.cos(th) * r * 500, y * 500, Math.sin(th) * r * 500], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return g;
  }, []);
  useFrame(({ camera }) => {
    mesh.current?.position.copy(camera.position);
    stars.current?.position.copy(camera.position);
    uniforms.uTop.value.copy(atm.skyTop);
    uniforms.uHorizon.value.copy(atm.skyHorizon);
    uniforms.uSunDir.value.copy(atm.sunDir);
    uniforms.uSun.value.copy(atm.sun);
    uniforms.uNight.value = atm.night;
    uniforms.uFlash.value = atm.lightning;
    const sm = stars.current?.material as THREE.PointsMaterial | undefined;
    if (sm) sm.opacity = Math.max(0, atm.night - 0.3) * (1 - atm.rain) * 1.3;
  });
  return (
    <group>
      <mesh ref={mesh} frustumCulled={false} renderOrder={-10}>
        <sphereGeometry args={[600, 32, 16]} />
        <shaderMaterial
          vertexShader={skyVert}
          fragmentShader={skyFrag}
          uniforms={uniforms}
          side={THREE.BackSide}
          depthWrite={false}
          fog={false}
        />
      </mesh>
      <points ref={stars} geometry={starGeo} frustumCulled={false} renderOrder={-9}>
        <pointsMaterial size={1.6} sizeAttenuation={false} color="#dfe8ff" transparent depthWrite={false} fog={false} />
      </points>
    </group>
  );
}
