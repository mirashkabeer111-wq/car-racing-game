import * as THREE from "three";

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("2D canvas unavailable");
  return [c, ctx];
}

function finish(c: HTMLCanvasElement, srgb = true): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

/** Road: 512px = 19 m across, 512px = 12 m along (one dash cycle). */
export function makeRoadTexture(): THREE.CanvasTexture {
  const W = 512;
  const H = 512;
  const [c, g] = makeCanvas(W, H);
  const px = (x: number) => ((x + 9.5) / 19) * W;
  g.fillStyle = "#2a2b30";
  g.fillRect(0, 0, W, H);
  g.fillStyle = "#33343a";
  g.fillRect(0, 0, px(-8.2), H);
  g.fillRect(px(8.2), 0, W - px(8.2), H);
  for (let i = 0; i < 9000; i++) {
    const v = Math.floor(30 + Math.random() * 50);
    g.fillStyle = `rgba(${v},${v},${v + 4},${0.25 + Math.random() * 0.4})`;
    g.fillRect(Math.random() * W, Math.random() * H, 1.5, 1.5);
  }
  // Tyre wear along lane centers.
  g.fillStyle = "rgba(0,0,0,0.13)";
  for (const lane of [-6, -2, 2, 6]) {
    for (const off of [-0.85, 0.85]) {
      const x = px(lane + off);
      g.fillRect(x - 6, 0, 12, H);
    }
  }
  // Edge lines.
  g.fillStyle = "#e9e9e4";
  const lw = (0.2 / 19) * W;
  g.fillRect(px(-8) - lw / 2, 0, lw, H);
  g.fillRect(px(8) - lw / 2, 0, lw, H);
  // Dashed lane lines: 4 m dash of a 12 m cycle.
  const dl = (0.16 / 19) * W;
  for (const x of [-4, 0, 4]) g.fillRect(px(x) - dl / 2, 0, dl, (H * 4) / 12);
  const t = finish(c);
  t.wrapS = THREE.ClampToEdgeWrapping;
  t.wrapT = THREE.RepeatWrapping;
  return t;
}

export function makeGroundTexture(): THREE.CanvasTexture {
  const [c, g] = makeCanvas(256, 256);
  g.fillStyle = "#26302a";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 5000; i++) {
    const r = Math.random();
    g.fillStyle = r < 0.5 ? "rgba(52,70,50,0.55)" : r < 0.8 ? "rgba(30,38,32,0.6)" : "rgba(70,66,52,0.4)";
    g.fillRect(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 3, 2 + Math.random() * 3);
  }
  const t = finish(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

/** Facade + matching emissive map with randomly lit windows. */
export function makeWindowTextures(): { map: THREE.CanvasTexture; emissive: THREE.CanvasTexture } {
  const W = 128;
  const H = 256;
  const [c, g] = makeCanvas(W, H);
  const [e, ge] = makeCanvas(W, H);
  g.fillStyle = "#1a1c24";
  g.fillRect(0, 0, W, H);
  ge.fillStyle = "#000";
  ge.fillRect(0, 0, W, H);
  const cols = 6;
  const rows = 18;
  const cw = W / cols;
  const rh = H / rows;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const lit = Math.random() < 0.38;
      const warm = Math.random() < 0.7;
      const col = lit ? (warm ? "#ffd49a" : "#a8dcff") : "#0d1018";
      g.fillStyle = lit ? col : "#2a3346";
      g.fillRect(x * cw + 3, y * rh + 3, cw - 6, rh - 5);
      if (lit) {
        ge.fillStyle = col;
        ge.fillRect(x * cw + 3, y * rh + 3, cw - 6, rh - 5);
      }
    }
  }
  return { map: finish(c), emissive: finish(e) };
}

export function makeGlowTexture(): THREE.CanvasTexture {
  const [c, g] = makeCanvas(64, 64);
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(0.4, "rgba(255,255,255,0.45)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  return finish(c);
}

export function makeCheckerTexture(): THREE.CanvasTexture {
  const [c, g] = makeCanvas(256, 64);
  for (let y = 0; y < 4; y++)
    for (let x = 0; x < 16; x++) {
      g.fillStyle = (x + y) % 2 ? "#111" : "#f4f4f4";
      g.fillRect(x * 16, y * 16, 16, 16);
    }
  return finish(c);
}

export function makeSignTexture(text: string, sub: string): THREE.CanvasTexture {
  const [c, g] = makeCanvas(1024, 160);
  g.fillStyle = "#07070d";
  g.fillRect(0, 0, 1024, 160);
  const grd = g.createLinearGradient(0, 0, 1024, 0);
  grd.addColorStop(0, "#3cc8ff");
  grd.addColorStop(1, "#b44dff");
  g.strokeStyle = grd;
  g.lineWidth = 6;
  g.strokeRect(6, 6, 1012, 148);
  g.shadowColor = "#3cc8ff";
  g.shadowBlur = 18;
  g.fillStyle = grd;
  g.font = "900 64px Orbitron, Arial Black, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text, 512, 70);
  g.shadowBlur = 0;
  g.fillStyle = "#c9d6ff";
  g.font = "600 28px Rajdhani, Arial, sans-serif";
  g.fillText(sub, 512, 126);
  return finish(c);
}
