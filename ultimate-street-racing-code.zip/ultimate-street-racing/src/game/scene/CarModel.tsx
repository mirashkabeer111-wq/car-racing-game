import { useGLTF } from "@react-three/drei";
import { useLayoutEffect, useMemo, type RefObject } from "react";
import type { CarDef } from "../data/cars";
import { BODY_URLS, buildCar, type CarHandle } from "./models";

export function CarModel({
  car,
  premium = false,
  handleRef,
}: {
  car: CarDef;
  premium?: boolean;
  handleRef?: RefObject<CarHandle | null>;
}) {
  const gltf = useGLTF(BODY_URLS[car.body]);
  const built = useMemo(() => buildCar(gltf.scene, car, premium), [gltf.scene, car, premium]);
  useLayoutEffect(() => {
    if (handleRef) handleRef.current = built.handle;
    return () => {
      if (handleRef) handleRef.current = null;
    };
  }, [built, handleRef]);
  return <primitive object={built.root} />;
}
