import { createContext, useContext } from "react";
import type { RaceState } from "../sim/race";
import type { Atmosphere } from "./atmosphere";
import type { Quality } from "../store";

export interface ParticlePool {
  count: number;
  s: Float32Array;
  x: Float32Array;
  y: Float32Array;
  vs: Float32Array;
  vx: Float32Array;
  vy: Float32Array;
  life: Float32Array;
  max: Float32Array;
  size: Float32Array;
  next: number;
}

export function makePool(count: number): ParticlePool {
  return {
    count,
    s: new Float32Array(count),
    x: new Float32Array(count),
    y: new Float32Array(count),
    vs: new Float32Array(count),
    vx: new Float32Array(count),
    vy: new Float32Array(count),
    life: new Float32Array(count),
    max: new Float32Array(count).fill(1),
    size: new Float32Array(count),
    next: 0,
  };
}

export function emit(
  p: ParticlePool,
  s: number,
  x: number,
  y: number,
  vs: number,
  vx: number,
  vy: number,
  life: number,
  size: number,
) {
  const i = p.next;
  p.next = (p.next + 1) % p.count;
  p.s[i] = s;
  p.x[i] = x;
  p.y[i] = y;
  p.vs[i] = vs;
  p.vx[i] = vx;
  p.vy[i] = vy;
  p.life[i] = life;
  p.max[i] = life;
  p.size[i] = size;
}

export interface Fx {
  shake: number;
  smoke: ParticlePool;
  sparks: ParticlePool;
}

export interface RaceCtx {
  sim: RaceState;
  atm: Atmosphere;
  fx: Fx;
  quality: Quality;
}

export const RaceContext = createContext<RaceCtx | null>(null);

export function useRace(): RaceCtx {
  const c = useContext(RaceContext);
  if (!c) throw new Error("useRace outside RaceScene");
  return c;
}

/** Distance ahead of the player for a looping scenery item. */
export function scrollAhead(base: number, s: number, loop: number, behind: number): number {
  const r = (((base - s + behind) % loop) + loop) % loop;
  return r - behind;
}
