import type { Mode, RaceResultCore } from "./race";

export interface LeaderEntry {
  name: string;
  mode: Mode;
  score: number;
  distance: number;
  time: number;
  carId: string;
  date: number;
  detail: string;
}

export interface SaveData {
  coins: number;
  unlocked: string[];
  selectedCar: string;
  careerUnlocked: number; // index of highest playable career event
  careerBest: Record<string, number>; // event id -> best place
  bestEndless: number;
  bestTT: number | null; // seconds
  leaderboard: LeaderEntry[];
  totalDistance: number;
  totalRaces: number;
}

export const START_COINS = 250;
export const PLACE_SHARE = [1, 0.6, 0.35, 0.15, 0.1, 0.05];

export function defaultSave(): SaveData {
  return {
    coins: START_COINS,
    unlocked: ["bmw-m4"],
    selectedCar: "bmw-m4",
    careerUnlocked: 0,
    careerBest: {},
    bestEndless: 0,
    bestTT: null,
    leaderboard: [],
    totalDistance: 0,
    totalRaces: 0,
  };
}

export type BuyResult = { ok: true; save: SaveData } | { ok: false; reason: "owned" | "coins" | "unknown" };

export function buyCar(save: SaveData, car: { id: string; price: number } | undefined): BuyResult {
  if (!car) return { ok: false, reason: "unknown" };
  if (save.unlocked.includes(car.id)) return { ok: false, reason: "owned" };
  if (save.coins < car.price) return { ok: false, reason: "coins" };
  return {
    ok: true,
    save: { ...save, coins: save.coins - car.price, unlocked: [...save.unlocked, car.id], selectedCar: car.id },
  };
}

/** Coins earned for a run: collected coins + score bonus + finishing bonus. */
export function computeReward(r: RaceResultCore, careerReward = 0): number {
  let coins = r.coins + Math.floor(r.score / 150);
  if (r.mode === "career" && r.status === "finished") {
    coins += Math.round(careerReward * (PLACE_SHARE[r.place - 1] ?? 0));
  }
  if (r.mode === "timetrial" && r.status === "finished") coins += 300;
  return Math.max(0, coins);
}

export function insertLeader(list: LeaderEntry[], entry: LeaderEntry, perMode = 10): LeaderEntry[] {
  const all = [...list, entry];
  const out: LeaderEntry[] = [];
  for (const mode of ["endless", "career", "timetrial"] as Mode[]) {
    const rows = all.filter((e) => e.mode === mode);
    rows.sort((a, b) => {
      if (mode === "timetrial") {
        const af = a.distance >= 6000 ? 0 : 1;
        const bf = b.distance >= 6000 ? 0 : 1;
        if (af !== bf) return af - bf;
        if (af === 0) return a.time - b.time;
        return b.distance - a.distance;
      }
      return b.score - a.score;
    });
    out.push(...rows.slice(0, perMode));
  }
  return out;
}

export interface ApplyOptions {
  carId: string;
  playerName: string;
  now: number;
  eventIndex?: number;
  eventId?: string;
  careerReward?: number;
}

export function applyResult(
  save: SaveData,
  r: RaceResultCore,
  o: ApplyOptions,
): { save: SaveData; reward: number; newBest: boolean } {
  const reward = computeReward(r, o.careerReward ?? 0);
  let newBest = false;
  const next: SaveData = {
    ...save,
    coins: save.coins + reward,
    totalDistance: save.totalDistance + r.distance,
    totalRaces: save.totalRaces + 1,
  };
  if (r.mode === "endless" && r.score > save.bestEndless) {
    next.bestEndless = r.score;
    newBest = true;
  }
  if (r.mode === "timetrial" && r.status === "finished" && (save.bestTT === null || r.time < save.bestTT)) {
    next.bestTT = r.time;
    newBest = true;
  }
  if (r.mode === "career" && r.status === "finished" && o.eventId !== undefined && o.eventIndex !== undefined) {
    const prev = save.careerBest[o.eventId];
    if (prev === undefined || r.place < prev) {
      next.careerBest = { ...save.careerBest, [o.eventId]: r.place };
      newBest = true;
    }
    if (r.place <= 3 && o.eventIndex >= save.careerUnlocked) next.careerUnlocked = o.eventIndex + 1;
  }
  const detail =
    r.mode === "career"
      ? `P${r.place}/${r.racers}`
      : r.mode === "timetrial"
        ? r.status === "finished"
          ? `${r.time.toFixed(2)}s`
          : `${(r.distance / 1000).toFixed(2)} km`
        : `${(r.distance / 1000).toFixed(2)} km`;
  next.leaderboard = insertLeader(save.leaderboard, {
    name: o.playerName || "Racer",
    mode: r.mode,
    score: r.score,
    distance: r.distance,
    time: r.time,
    carId: o.carId,
    date: o.now,
    detail,
  });
  return { save: next, reward, newBest };
}
