// Road layout (metres). The road runs along +s (forward); x is lateral, +x = screen right.
export const LANES = [-6, -2, 2, 6] as const;
export const LANE_WIDTH = 4;
export const ROAD_HALF = 8;
export const RAIL_X = 9.1;
export const PLAYER_HALF_W = 1.0;
export const PLAYER_HALF_L = 2.2;

export interface TrafficKind {
  key: "sedan" | "suv" | "taxi" | "van" | "truck" | "police" | "delivery";
  halfW: number;
  halfL: number;
  minV: number;
  maxV: number;
}

export const TRAFFIC_SCALE = 1.55;
export const TRAFFIC_KINDS: TrafficKind[] = [
  { key: "sedan", halfW: 1.12, halfL: 1.98, minV: 17, maxV: 26 },
  { key: "suv", halfW: 1.12, halfL: 2.1, minV: 16, maxV: 24 },
  { key: "taxi", halfW: 1.12, halfL: 2.13, minV: 16, maxV: 25 },
  { key: "van", halfW: 1.12, halfL: 2.13, minV: 14, maxV: 22 },
  { key: "truck", halfW: 1.12, halfL: 2.3, minV: 13, maxV: 20 },
  { key: "police", halfW: 1.12, halfL: 2.42, minV: 20, maxV: 28 },
  { key: "delivery", halfW: 1.12, halfL: 2.52, minV: 12, maxV: 19 },
];
export const SLOTS_PER_KIND = 4;
export const TRAFFIC_SLOTS = TRAFFIC_KINDS.length * SLOTS_PER_KIND;

export const COUNTDOWN = 3.2;
export const TT_DISTANCE = 6000;
export const TT_CHECKPOINT = 1000;
export const TT_START_TIME = 32;
export const TT_BONUS = 16;
export const MAX_PICKUPS = 60;
export const MAX_CONES = 40;
export const MAX_BARRIERS = 12;

/** Handling feel. Tune these, not the model. */
export const FEEL = {
  BRAKE: 28,
  HANDBRAKE_DECEL: 6,
  ROLL: 0.8,
  AIR: 0.0005,
  NITRO_ACCEL: 14,
  NITRO_TOP_MULT: 1.3,
  NITRO_REGEN: 0.012,
  STEER_RATE: 2.6,
  CENTER: 5,
  MAX_HEADING: 0.4,
  HEADING_REF: 20,
  DRIFT_HEADING: 0.75,
  GRIP: 9,
  DRIFT_GRIP: 1.5,
  RAIL_FRICTION: 1.4,
} as const;
