import { mulberry32 } from "./rng";
import {
  COUNTDOWN,
  FEEL,
  LANES,
  MAX_BARRIERS,
  MAX_CONES,
  MAX_PICKUPS,
  PLAYER_HALF_L,
  PLAYER_HALF_W,
  RAIL_X,
  SLOTS_PER_KIND,
  TRAFFIC_KINDS,
  TRAFFIC_SLOTS,
  TT_BONUS,
  TT_CHECKPOINT,
  TT_DISTANCE,
  TT_START_TIME,
} from "./constants";

export type Mode = "endless" | "career" | "timetrial";
export type RaceStatus = "countdown" | "racing" | "finished" | "wrecked" | "timeout";

export interface CarSpec {
  topSpeed: number; // km/h
  accel: number; // m/s^2
  handling: number; // steering multiplier
  nitro: number; // seconds of full nitro
  grip: number; // grip multiplier
}

export interface OpponentSpec {
  name: string;
  carId: string;
  top: number; // m/s cruising speed
}

export interface CareerSpec {
  distance: number;
  opponents: OpponentSpec[];
  traffic: number; // 0..1 density
  obstacles: boolean;
}

export interface RaceConfig {
  mode: Mode;
  car: CarSpec;
  seed: number;
  career?: CareerSpec;
}

export interface ControlInput {
  throttle: number;
  brake: number;
  steer: number; // -1 left .. +1 right
  handbrake: boolean;
  nitro: boolean;
}

export interface Player {
  s: number;
  x: number;
  v: number;
  heading: number; // body angle vs road, + = pointing right
  dir: number; // travel angle vs road
  nitro: number; // 0..1
  damage: number; // 0..100
  drifting: boolean;
  driftPoints: number;
  nitroActive: boolean;
  braking: boolean;
  rpm: number;
  gear: number;
  railContact: boolean;
  steer: number;
}

export interface TrafficCar {
  id: number;
  slot: number;
  kind: number;
  s: number;
  x: number;
  v: number;
  cruise: number;
  targetX: number;
  passed: boolean;
  hit: boolean;
  hitTimer: number;
  spin: number;
  yaw: number;
  cooldown: number;
}

export interface Opponent {
  id: number;
  name: string;
  carId: string;
  s: number;
  x: number;
  v: number;
  top: number;
  targetX: number;
  finished: boolean;
  finishTime: number;
  yaw: number;
  laneTimer: number;
}

export interface Pickup {
  id: number;
  type: "coin" | "nitro";
  s: number;
  x: number;
}

export interface Obstacle {
  id: number;
  type: "cone" | "barrier";
  s: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  spin: number;
  hit: boolean;
}

export type GameEvent =
  | { t: "countdown"; n: number }
  | { t: "go" }
  | { t: "crash"; power: number }
  | { t: "scrape" }
  | { t: "coin" }
  | { t: "nitroPickup" }
  | { t: "nearMiss"; bonus: number; combo: number }
  | { t: "drift"; points: number }
  | { t: "checkpoint"; bonus: number }
  | { t: "cone" }
  | { t: "finish" }
  | { t: "wrecked" }
  | { t: "timeout" };

export interface RaceState {
  config: RaceConfig;
  status: RaceStatus;
  time: number;
  raceTime: number;
  countdown: number;
  rng: () => number;
  nextId: number;
  player: Player;
  traffic: TrafficCar[];
  opponents: Opponent[];
  pickups: Pickup[];
  obstacles: Obstacle[];
  events: GameEvent[];
  score: number;
  coins: number;
  nearMisses: number;
  combo: number;
  comboTimer: number;
  bestDrift: number;
  topSpeed: number;
  difficulty: number;
  nextPickupS: number;
  nextObstacleS: number;
  checkpointIndex: number;
  timeLeft: number;
  finishDistance: number;
  place: number;
  wetness: number;
  usedSlots: boolean[];
  scrapeTimer: number;
}

export interface RaceResultCore {
  mode: Mode;
  status: RaceStatus;
  score: number;
  distance: number;
  coins: number;
  nearMisses: number;
  topSpeed: number; // km/h
  bestDrift: number;
  time: number;
  place: number;
  racers: number;
}

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export function createRace(config: RaceConfig): RaceState {
  const rng = mulberry32(config.seed);
  const st: RaceState = {
    config,
    status: "countdown",
    time: 0,
    raceTime: 0,
    countdown: COUNTDOWN,
    rng,
    nextId: 1,
    player: {
      s: 0,
      x: 2,
      v: 0,
      heading: 0,
      dir: 0,
      nitro: 1,
      damage: 0,
      drifting: false,
      driftPoints: 0,
      nitroActive: false,
      braking: false,
      rpm: 900,
      gear: 1,
      railContact: false,
      steer: 0,
    },
    traffic: [],
    opponents: [],
    pickups: [],
    obstacles: [],
    events: [],
    score: 0,
    coins: 0,
    nearMisses: 0,
    combo: 0,
    comboTimer: 0,
    bestDrift: 0,
    topSpeed: 0,
    difficulty: 0,
    nextPickupS: 90,
    nextObstacleS: 700,
    checkpointIndex: 0,
    timeLeft: TT_START_TIME,
    finishDistance:
      config.mode === "career"
        ? (config.career?.distance ?? 3000)
        : config.mode === "timetrial"
          ? TT_DISTANCE
          : Number.POSITIVE_INFINITY,
    place: 1,
    wetness: 0,
    usedSlots: new Array<boolean>(TRAFFIC_SLOTS).fill(false),
    scrapeTimer: 0,
  };

  if (config.mode === "career" && config.career) {
    const grid: [number, number][] = [
      [-6, 9],
      [-2, 9],
      [6, 9],
      [-6, 0],
      [6, 0],
      [-2, -9],
    ];
    config.career.opponents.slice(0, grid.length).forEach((o, i) => {
      const g = grid[i] ?? [0, 0];
      st.opponents.push({
        id: st.nextId++,
        name: o.name,
        carId: o.carId,
        s: g[1],
        x: g[0],
        v: 0,
        top: o.top,
        targetX: g[0],
        finished: false,
        finishTime: 0,
        yaw: 0,
        laneTimer: 2 + rng() * 3,
      });
    });
  }

  // Seed some traffic up the road so the start is not empty.
  const startS = config.mode === "career" ? 260 : 110;
  for (let i = 0; i < 6; i++) spawnTraffic(st, startS + i * 55 + rng() * 30);
  return st;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */

function trafficTarget(st: RaceState): number {
  const m = st.config.mode;
  if (m === "endless") return Math.round(7 + 19 * st.difficulty);
  if (m === "timetrial") return 11;
  return Math.round(4 + 14 * (st.config.career?.traffic ?? 0.3));
}

function laneBlocked(
  st: RaceState,
  x: number,
  from: number,
  to: number,
  ignoreId = -1,
  includePlayer = true,
): boolean {
  for (const t of st.traffic) {
    if (t.id === ignoreId) continue;
    if (Math.abs(t.x - x) < 2.6 || Math.abs(t.targetX - x) < 2.6) {
      if (t.s > from && t.s < to) return true;
    }
  }
  for (const o of st.opponents) {
    if (o.id === ignoreId) continue;
    if (Math.abs(o.x - x) < 2.6 && o.s > from && o.s < to) return true;
  }
  for (const ob of st.obstacles) {
    if (!ob.hit && Math.abs(ob.x - x) < 2.4 && ob.s > from - 4 && ob.s < to + 4) return true;
  }
  if (includePlayer) {
    const p = st.player;
    if (Math.abs(p.x - x) < 2.8 && p.s > from - 6 && p.s < to + 2) return true;
  }
  return false;
}

export function spawnTraffic(st: RaceState, s: number): boolean {
  const rng = st.rng;
  const lane = LANES[Math.floor(rng() * LANES.length)] ?? 2;
  if (laneBlocked(st, lane, s - 24, s + 24, -1, false)) return false;
  // Always leave a gap: no more than 3 cars side by side.
  let near = 0;
  for (const t of st.traffic) if (Math.abs(t.s - s) < 18) near++;
  if (near >= 3) return false;
  // Pick a free slot (slot % kinds = model kind).
  const start = Math.floor(rng() * TRAFFIC_SLOTS);
  let slot = -1;
  for (let i = 0; i < TRAFFIC_SLOTS; i++) {
    const c = (start + i) % TRAFFIC_SLOTS;
    if (!st.usedSlots[c]) {
      slot = c;
      break;
    }
  }
  if (slot < 0) return false;
  const kindIdx = slot % TRAFFIC_KINDS.length;
  const kind = TRAFFIC_KINDS[kindIdx];
  if (!kind) return false;
  const boost = st.config.mode === "endless" ? 1 + 0.18 * st.difficulty : 1;
  const cruise = (kind.minV + rng() * (kind.maxV - kind.minV)) * boost;
  st.usedSlots[slot] = true;
  st.traffic.push({
    id: st.nextId++,
    slot,
    kind: kindIdx,
    s,
    x: lane,
    v: cruise,
    cruise,
    targetX: lane,
    passed: false,
    hit: false,
    hitTimer: 0,
    spin: 0,
    yaw: 0,
    cooldown: 2 + rng() * 4,
  });
  return true;
}

export function slotInstance(slot: number): { kind: number; index: number } {
  return { kind: slot % TRAFFIC_KINDS.length, index: Math.floor(slot / TRAFFIC_KINDS.length) };
}
export const INSTANCES_PER_KIND = SLOTS_PER_KIND;

/* ------------------------------------------------------------------ */
/* Player                                                               */
/* ------------------------------------------------------------------ */

export function topSpeedMs(st: RaceState): number {
  return (st.config.car.topSpeed / 3.6) * (1 - st.player.damage / 300);
}

function stepPlayer(st: RaceState, input: ControlInput, dt: number) {
  const c = st.config.car;
  const p = st.player;
  const top = topSpeedMs(st);
  const wetGrip = 1 - 0.2 * st.wetness;

  const wantsNitro = input.nitro && p.nitro > 0.01 && p.v > 4;
  p.nitroActive = wantsNitro;
  const maxV = top * (wantsNitro ? FEEL.NITRO_TOP_MULT : 1);

  let a = 0;
  if (input.throttle > 0) a += c.accel * input.throttle * Math.max(0, 1 - (p.v / maxV) ** 2);
  else a -= FEEL.ROLL + FEEL.AIR * p.v * p.v;
  if (wantsNitro) {
    a += FEEL.NITRO_ACCEL;
    p.nitro = Math.max(0, p.nitro - dt / c.nitro);
  } else {
    p.nitro = Math.min(1, p.nitro + dt * FEEL.NITRO_REGEN);
  }
  if (p.v > maxV) a -= (p.v - maxV) * 1.2;
  if (input.brake > 0) a -= FEEL.BRAKE * input.brake;
  if (input.handbrake) a -= FEEL.HANDBRAKE_DECEL;
  p.v = Math.max(0, p.v + a * dt);
  p.braking = input.brake > 0.1 || input.handbrake;

  // Steering: heading is the body angle, dir is where the car actually travels.
  const drift = input.handbrake && p.v > 14;
  const vSafe = Math.max(p.v, 1);
  const maxH = drift
    ? FEEL.DRIFT_HEADING * Math.min(1, 34 / vSafe) + 0.12
    : FEEL.MAX_HEADING * Math.min(1, FEEL.HEADING_REF / vSafe);
  const speedFactor = Math.min(1, p.v / 6);
  p.steer = input.steer;
  if (Math.abs(input.steer) > 0.01) {
    p.heading += input.steer * FEEL.STEER_RATE * c.handling * speedFactor * dt * (drift ? 1.7 : 1);
  } else {
    p.heading *= Math.exp(-FEEL.CENTER * dt);
  }
  if (Math.abs(p.heading) > maxH) {
    p.heading = Math.sign(p.heading) * Math.max(maxH, Math.abs(p.heading) - 1.6 * dt);
  }
  const grip = (drift ? FEEL.DRIFT_GRIP : FEEL.GRIP * c.grip) * wetGrip;
  p.dir += (p.heading - p.dir) * (1 - Math.exp(-grip * dt));

  // Drift scoring.
  const slip = Math.abs(p.heading - p.dir);
  const wasDrifting = p.drifting;
  p.drifting = slip > 0.07 && p.v > 14;
  if (p.drifting) {
    p.driftPoints += slip * p.v * dt * 14;
    p.nitro = Math.min(1, p.nitro + dt * 0.12);
  } else if (wasDrifting) {
    const pts = Math.round(p.driftPoints);
    if (pts > 40) {
      st.score += pts;
      st.bestDrift = Math.max(st.bestDrift, pts);
      st.events.push({ t: "drift", points: pts });
    }
    p.driftPoints = 0;
  }

  p.x += Math.sin(p.dir) * p.v * dt;
  p.s += Math.cos(p.dir) * p.v * dt;

  // Guard rails.
  const lim = RAIL_X - 0.25 - PLAYER_HALF_W;
  p.railContact = false;
  if (Math.abs(p.x) > lim) {
    const side = Math.sign(p.x);
    p.x = side * lim;
    p.railContact = true;
    if (p.v > 6) {
      p.v -= p.v * FEEL.RAIL_FRICTION * dt;
      p.damage = Math.min(100, p.damage + dt * 5 * (p.v / 40));
      st.scrapeTimer -= dt;
      if (st.scrapeTimer <= 0) {
        st.events.push({ t: "scrape" });
        st.scrapeTimer = 0.3;
      }
    }
    if (Math.sign(p.heading) === side) p.heading = -side * 0.03;
    if (Math.sign(p.dir) === side) p.dir = -side * 0.02;
  }

  // Gearbox / RPM for the dashboard.
  const ratio = clamp(p.v / Math.max(top, 1), 0, 1.3) * 6;
  p.gear = clamp(Math.floor(ratio) + 1, 1, 6);
  const within = clamp(ratio - (p.gear - 1), 0, 1);
  p.rpm = p.v < 1 ? 900 + input.throttle * 3000 : 1600 + within * 6200 + (wantsNitro ? 300 : 0);
  st.topSpeed = Math.max(st.topSpeed, p.v);
}

/* ------------------------------------------------------------------ */
/* Traffic & AI                                                         */
/* ------------------------------------------------------------------ */

function stepTraffic(st: RaceState, dt: number) {
  const p = st.player;
  const rng = st.rng;
  for (let i = st.traffic.length - 1; i >= 0; i--) {
    const t = st.traffic[i];
    if (!t) continue;
    const kind = TRAFFIC_KINDS[t.kind];
    if (!kind) continue;
    t.cooldown -= dt;
    if (t.hit) {
      t.hitTimer += dt;
      t.v *= Math.exp(-1.4 * dt);
      t.x += t.spin * 1.6 * dt;
      t.yaw += t.spin * 2.4 * dt * Math.max(0, 1 - t.hitTimer / 2);
    } else {
      // Look for something slower ahead in our lane.
      let blockerGap = Infinity;
      let blockerV = t.cruise;
      for (const o of st.traffic) {
        if (o === t) continue;
        if (Math.abs(o.x - t.x) < 2.4) {
          const gap = o.s - t.s;
          if (gap > 0 && gap < blockerGap) {
            blockerGap = gap;
            blockerV = o.hit ? 0 : o.v;
          }
        }
      }
      for (const ob of st.obstacles) {
        if (!ob.hit && Math.abs(ob.x - t.x) < 2.4) {
          const gap = ob.s - t.s;
          if (gap > 0 && gap < blockerGap) {
            blockerGap = gap;
            blockerV = 0;
          }
        }
      }
      let target = t.cruise;
      if (blockerGap < 34) {
        if (t.cooldown <= 0 && Math.abs(t.targetX - t.x) < 0.3) changeLane(st, t);
        if (blockerGap < 22) target = Math.min(target, blockerV);
      } else if (t.cooldown <= 0 && rng() < dt * 0.05 * (0.4 + st.difficulty)) {
        changeLane(st, t);
      }
      const dv = target - t.v;
      t.v += clamp(dv, -9 * dt, 3 * dt);
      const dx = t.targetX - t.x;
      const step = Math.sign(dx) * Math.min(Math.abs(dx), 2.4 * dt);
      t.x += step;
      t.yaw = -Math.atan2(step / Math.max(dt, 1e-4), Math.max(t.v, 1)) * 0.9;
    }
    t.s += t.v * dt;
    const gone = t.s < p.s - 60 || t.s > p.s + 520 || (t.hit && t.hitTimer > 4 && t.s < p.s + 5);
    if (gone) {
      st.usedSlots[t.slot] = false;
      st.traffic.splice(i, 1);
    }
  }
}

function changeLane(st: RaceState, t: TrafficCar) {
  const idx = LANES.findIndex((l) => Math.abs(l - t.x) < 1);
  if (idx < 0) return;
  const options = [idx - 1, idx + 1].filter((i) => i >= 0 && i < LANES.length);
  if (st.rng() < 0.5) options.reverse();
  for (const o of options) {
    const lx = LANES[o];
    if (lx === undefined) continue;
    if (!laneBlocked(st, lx, t.s - 14, t.s + 26, t.id, true)) {
      t.targetX = lx;
      t.cooldown = 3 + st.rng() * 4;
      return;
    }
  }
  t.cooldown = 1;
}

function stepOpponents(st: RaceState, dt: number, racing: boolean) {
  const p = st.player;
  for (const o of st.opponents) {
    let target = 0;
    if (racing) {
      const gap = o.s - p.s;
      const rubber = gap < -70 ? 1.1 : gap > 140 ? 0.9 : 1;
      target = o.top * rubber;
      // Look ahead for blockers in lane.
      let blockGap = Infinity;
      let blockV = target;
      for (const t of st.traffic) {
        if (Math.abs(t.x - o.x) < 2.5) {
          const g = t.s - o.s;
          if (g > 0 && g < blockGap) {
            blockGap = g;
            blockV = t.hit ? 0 : t.v;
          }
        }
      }
      for (const ob of st.obstacles) {
        if (!ob.hit && Math.abs(ob.x - o.x) < 2.4) {
          const g = ob.s - o.s;
          if (g > 0 && g < blockGap) {
            blockGap = g;
            blockV = 0;
          }
        }
      }
      o.laneTimer -= dt;
      if (blockGap < 55 && Math.abs(o.targetX - o.x) < 0.4) {
        const idx = LANES.findIndex((l) => Math.abs(l - o.x) < 1.2);
        const opts = [idx - 1, idx + 1].filter((i) => i >= 0 && i < LANES.length);
        if (st.rng() < 0.5) opts.reverse();
        let moved = false;
        for (const i of opts) {
          const lx = LANES[i];
          if (lx !== undefined && !laneBlocked(st, lx, o.s - 10, o.s + 45, o.id, false)) {
            o.targetX = lx;
            moved = true;
            break;
          }
        }
        if (!moved && blockGap < 30) target = Math.min(target, Math.max(0, blockV - 1));
      }
    }
    const accel = o.v < 20 ? 9 : 6;
    o.v += clamp(target - o.v, -14 * dt, accel * dt);
    const dx = o.targetX - o.x;
    const step = Math.sign(dx) * Math.min(Math.abs(dx), 4.5 * dt);
    o.x += step;
    o.yaw = -Math.atan2(step / Math.max(dt, 1e-4), Math.max(o.v, 1)) * 0.9;
    o.s += o.v * dt;

    // Opponents do not drive through traffic.
    for (const t of st.traffic) {
      const kind = TRAFFIC_KINDS[t.kind];
      if (!kind) continue;
      if (Math.abs(t.x - o.x) < kind.halfW + PLAYER_HALF_W && Math.abs(t.s - o.s) < kind.halfL + PLAYER_HALF_L) {
        if (o.s < t.s) {
          o.s = t.s - kind.halfL - PLAYER_HALF_L;
          o.v = Math.min(o.v, t.v);
        }
      }
    }
    if (!o.finished && o.s >= st.finishDistance) {
      o.finished = true;
      o.finishTime = st.raceTime;
    }
  }
}

/* ------------------------------------------------------------------ */
/* Collisions                                                           */
/* ------------------------------------------------------------------ */

interface Body {
  s: number;
  x: number;
  v: number;
}

/** Resolve player vs another car. Returns damage dealt (0 when no contact). */
export function resolveCarHit(st: RaceState, o: Body, halfW: number, halfL: number): number {
  const p = st.player;
  const dx = p.x - o.x;
  const ds = p.s - o.s;
  const ox = PLAYER_HALF_W + halfW - Math.abs(dx);
  const os = PLAYER_HALF_L + halfL - Math.abs(ds);
  if (ox <= 0 || os <= 0) return 0;
  let dmg: number;
  const side = Math.sign(dx) || 1;
  if (ox < os * 0.55) {
    // Side swipe.
    p.x += side * ox;
    o.x -= side * 0.35;
    p.heading *= 0.3;
    p.dir *= 0.3;
    p.v *= 0.92;
    dmg = 4 + Math.abs(p.v - o.v) * 0.25;
  } else if (ds < 0) {
    // Rear-end: player drove into it.
    const rel = Math.max(0, p.v - o.v);
    p.s = o.s - (PLAYER_HALF_L + halfL) - 0.05;
    dmg = clamp(8 + rel * 0.9, 8, 45);
    p.v = Math.max(0, o.v * 0.7 - 2);
    o.v += rel * 0.35;
  } else {
    // Hit from behind.
    p.s = o.s + PLAYER_HALF_L + halfL + 0.05;
    p.v += 3;
    o.v *= 0.6;
    dmg = 6;
  }
  p.damage = Math.min(100, p.damage + dmg);
  st.combo = 0;
  st.events.push({ t: "crash", power: dmg });
  return dmg;
}

function stepCollisions(st: RaceState) {
  const p = st.player;
  for (const t of st.traffic) {
    const kind = TRAFFIC_KINDS[t.kind];
    if (!kind) continue;
    if (!t.hit) {
      const dmg = resolveCarHit(st, t, kind.halfW, kind.halfL);
      if (dmg > 0) {
        t.hit = true;
        t.hitTimer = 0;
        t.spin = (Math.sign(t.x - p.x) || 1) * (0.6 + st.rng() * 1.2);
        t.passed = true;
      }
    }
    // Near miss: pass a car closely at speed.
    if (!t.passed && p.s > t.s) {
      t.passed = true;
      if (!t.hit && p.v > 22 && Math.abs(p.x - t.x) < PLAYER_HALF_W + kind.halfW + 1.3) {
        st.combo = Math.min(10, st.combo + 1);
        st.comboTimer = 3.5;
        const bonus = 60 * st.combo;
        st.score += bonus;
        st.nearMisses++;
        p.nitro = Math.min(1, p.nitro + 0.1);
        st.events.push({ t: "nearMiss", bonus, combo: st.combo });
      }
    }
  }
  for (const o of st.opponents) {
    const dmg = resolveCarHit(st, o, PLAYER_HALF_W, PLAYER_HALF_L);
    if (dmg > 0) o.v *= 0.85;
  }
  // Pickups.
  for (let i = st.pickups.length - 1; i >= 0; i--) {
    const k = st.pickups[i];
    if (!k) continue;
    if (Math.abs(k.x - p.x) < 1.7 && Math.abs(k.s - p.s) < 2.6) {
      if (k.type === "coin") {
        st.coins++;
        st.score += 25;
        st.events.push({ t: "coin" });
      } else {
        p.nitro = Math.min(1, p.nitro + 0.45);
        st.events.push({ t: "nitroPickup" });
      }
      st.pickups.splice(i, 1);
    } else if (k.s < p.s - 30) {
      st.pickups.splice(i, 1);
    }
  }
  // Obstacles.
  for (let i = st.obstacles.length - 1; i >= 0; i--) {
    const ob = st.obstacles[i];
    if (!ob) continue;
    if (!ob.hit) {
      const hw = ob.type === "cone" ? 0.45 : 1.0;
      if (Math.abs(ob.x - p.x) < PLAYER_HALF_W + hw && Math.abs(ob.s - p.s) < PLAYER_HALF_L + hw) {
        ob.hit = true;
        const side = Math.sign(ob.x - p.x) || 1;
        if (ob.type === "cone") {
          ob.vy = 5 + st.rng() * 3;
          ob.vx = side * (2 + st.rng() * 3);
          ob.spin = 8 * side;
          p.v *= 0.95;
          p.damage = Math.min(100, p.damage + 2);
          st.events.push({ t: "cone" });
        } else {
          ob.vy = 3;
          ob.vx = side * 2;
          ob.spin = 3 * side;
          const rel = p.v;
          p.v *= 0.5;
          p.damage = Math.min(100, p.damage + clamp(8 + rel * 0.25, 8, 26));
          st.combo = 0;
          st.events.push({ t: "crash", power: 18 });
        }
      }
    }
    if (ob.s < p.s - 40) st.obstacles.splice(i, 1);
  }
}

function stepObstacles(st: RaceState, dt: number) {
  for (const ob of st.obstacles) {
    if (!ob.hit) continue;
    if (ob.y > 0 || ob.vy > 0) {
      ob.vy -= 22 * dt;
      ob.y = Math.max(0, ob.y + ob.vy * dt);
      ob.x += ob.vx * dt;
      ob.s += st.player.v * 0.6 * dt;
      ob.rot += ob.spin * dt;
      if (ob.y === 0 && ob.vy < 0) ob.vy = 0;
    }
  }
}

/* ------------------------------------------------------------------ */
/* Spawning                                                             */
/* ------------------------------------------------------------------ */

function stepSpawns(st: RaceState) {
  const p = st.player;
  const rng = st.rng;
  const target = trafficTarget(st);
  for (let k = 0; k < 2 && st.traffic.length < target; k++) {
    spawnTraffic(st, p.s + 170 + rng() * 200);
  }
  // Coin rows and nitro bottles.
  if (p.s + 320 > st.nextPickupS && st.pickups.length < MAX_PICKUPS - 6) {
    const lane = LANES[Math.floor(rng() * LANES.length)] ?? 2;
    if (rng() < 0.16) {
      st.pickups.push({ id: st.nextId++, type: "nitro", s: st.nextPickupS, x: lane });
    } else {
      const n = 5;
      const shift = rng() < 0.35 ? (rng() < 0.5 ? -4 : 4) : 0;
      const end = clamp(lane + shift, LANES[0], LANES[LANES.length - 1] ?? 6);
      for (let i = 0; i < n; i++) {
        const f = i / (n - 1);
        st.pickups.push({ id: st.nextId++, type: "coin", s: st.nextPickupS + i * 7, x: lane + (end - lane) * f });
      }
    }
    st.nextPickupS += 110 + rng() * 150;
  }
  // Roadworks.
  const obstaclesOn =
    st.config.mode === "endless" ? st.difficulty > 0.06 : st.config.mode === "career" ? !!st.config.career?.obstacles : true;
  if (obstaclesOn && p.s + 340 > st.nextObstacleS) {
    const s0 = st.nextObstacleS;
    const lane = LANES[Math.floor(rng() * LANES.length)] ?? 2;
    if (!laneBlocked(st, lane, s0 - 30, s0 + 40, -1, false)) {
      const cones = st.obstacles.filter((o) => o.type === "cone").length;
      const barriers = st.obstacles.filter((o) => o.type === "barrier").length;
      const dirSign = lane > 0 ? 1 : -1;
      if (cones < MAX_CONES - 5) {
        for (let i = 0; i < 4; i++) {
          st.obstacles.push(makeObstacle(st, "cone", s0 + i * 5, lane - dirSign * (1.8 - i * 0.9)));
        }
      }
      if (barriers < MAX_BARRIERS) st.obstacles.push(makeObstacle(st, "barrier", s0 + 24, lane));
    }
    const gap = st.config.mode === "endless" ? 900 - 500 * st.difficulty : 700;
    st.nextObstacleS += gap + rng() * 400;
  }
}

function makeObstacle(st: RaceState, type: "cone" | "barrier", s: number, x: number): Obstacle {
  return { id: st.nextId++, type, s, x, y: 0, vx: 0, vy: 0, rot: st.rng() * Math.PI, spin: 0, hit: false };
}

/* ------------------------------------------------------------------ */
/* Main step                                                            */
/* ------------------------------------------------------------------ */

export function stepRace(st: RaceState, input: ControlInput, dt: number): void {
  st.time += dt;
  const p = st.player;

  if (st.status === "countdown") {
    const before = Math.ceil(st.countdown);
    st.countdown -= dt;
    const after = Math.ceil(st.countdown);
    if (after !== before && after > 0) st.events.push({ t: "countdown", n: after });
    p.rpm = 900 + input.throttle * 5200;
    stepTraffic(st, dt);
    if (st.countdown <= 0) {
      st.status = "racing";
      st.events.push({ t: "go" });
    }
    return;
  }

  if (st.status !== "racing") {
    // Roll to a stop after the race ends.
    p.v *= Math.exp(-1.2 * dt);
    p.nitroActive = false;
    p.drifting = false;
    p.s += p.v * dt;
    stepTraffic(st, dt);
    stepOpponents(st, dt, true);
    stepObstacles(st, dt);
    return;
  }

  st.raceTime += dt;
  if (st.config.mode === "endless") st.difficulty = Math.min(1, p.s / 12000);
  else if (st.config.mode === "timetrial") st.difficulty = 0.35;
  else st.difficulty = st.config.career?.traffic ?? 0.3;

  stepPlayer(st, input, dt);
  stepTraffic(st, dt);
  stepOpponents(st, dt, true);
  stepCollisions(st);
  stepObstacles(st, dt);
  stepSpawns(st);

  // Score for distance travelled at speed.
  st.score += p.v * dt * 0.4 * (1 + st.difficulty);
  if (st.comboTimer > 0) {
    st.comboTimer -= dt;
    if (st.comboTimer <= 0) st.combo = 0;
  }

  // Race position.
  let ahead = 0;
  for (const o of st.opponents) if (o.finished || o.s > p.s) ahead++;
  st.place = 1 + ahead;

  // Mode rules.
  if (st.config.mode === "timetrial") {
    st.timeLeft -= dt;
    const next = (st.checkpointIndex + 1) * TT_CHECKPOINT;
    if (p.s >= next && next < TT_DISTANCE) {
      st.checkpointIndex++;
      st.timeLeft += TT_BONUS;
      st.events.push({ t: "checkpoint", bonus: TT_BONUS });
    }
  }
  if (p.s >= st.finishDistance) {
    st.status = "finished";
    st.events.push({ t: "finish" });
    return;
  }
  if (p.damage >= 100) {
    st.status = "wrecked";
    st.events.push({ t: "wrecked" });
    return;
  }
  if (st.config.mode === "timetrial" && st.timeLeft <= 0) {
    st.timeLeft = 0;
    st.status = "timeout";
    st.events.push({ t: "timeout" });
  }
}

export function getResult(st: RaceState): RaceResultCore {
  return {
    mode: st.config.mode,
    status: st.status,
    score: Math.round(st.score),
    distance: Math.round(st.player.s),
    coins: st.coins,
    nearMisses: st.nearMisses,
    topSpeed: Math.round(st.topSpeed * 3.6),
    bestDrift: st.bestDrift,
    time: st.raceTime,
    place: st.place,
    racers: st.opponents.length + 1,
  };
}
