/**
 * Synthesized sound (WebAudio): engine tone follows RPM, plus crash / coin /
 * near-miss / nitro / skid / rain effects. No audio files needed.
 */
class AudioEngine {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  engineGain: GainNode | null = null;
  osc1: OscillatorNode | null = null;
  osc2: OscillatorNode | null = null;
  filter: BiquadFilterNode | null = null;
  noise: AudioBuffer | null = null;
  skidGain: GainNode | null = null;
  rainGain: GainNode | null = null;
  windGain: GainNode | null = null;
  volume = 0.7;

  unlock() {
    if (typeof window === "undefined") return;
    if (!this.ctx) {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(ctx.destination);
      const len = ctx.sampleRate * 2;
      this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.skidGain = this.loopNoise(1800, "bandpass", 0);
      this.rainGain = this.loopNoise(3000, "highpass", 0);
      this.windGain = this.loopNoise(600, "lowpass", 0);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  private loopNoise(freq: number, type: BiquadFilterType, gain: number): GainNode | null {
    if (!this.ctx || !this.noise || !this.master) return null;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.value = gain;
    src.connect(f).connect(g).connect(this.master);
    src.start();
    return g;
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05);
  }

  startEngine() {
    if (!this.ctx || !this.master || this.osc1) return;
    const ctx = this.ctx;
    this.filter = ctx.createBiquadFilter();
    this.filter.type = "lowpass";
    this.filter.frequency.value = 900;
    this.filter.Q.value = 4;
    this.engineGain = ctx.createGain();
    this.engineGain.gain.value = 0;
    this.osc1 = ctx.createOscillator();
    this.osc1.type = "sawtooth";
    this.osc2 = ctx.createOscillator();
    this.osc2.type = "square";
    const g2 = ctx.createGain();
    g2.gain.value = 0.35;
    this.osc1.connect(this.filter);
    this.osc2.connect(g2).connect(this.filter);
    this.filter.connect(this.engineGain).connect(this.master);
    this.osc1.start();
    this.osc2.start();
  }

  stopEngine() {
    try {
      this.osc1?.stop();
      this.osc2?.stop();
    } catch {
      /* already stopped */
    }
    this.osc1 = this.osc2 = null;
    this.engineGain?.disconnect();
    this.engineGain = null;
    this.setLoops(0, 0, 0);
  }

  engine(rpm: number, throttle: number, nitro: boolean, muted: boolean) {
    if (!this.ctx || !this.osc1 || !this.osc2 || !this.engineGain || !this.filter) return;
    const t = this.ctx.currentTime;
    const f = 38 + (rpm / 8000) * 150;
    this.osc1.frequency.setTargetAtTime(f, t, 0.04);
    this.osc2.frequency.setTargetAtTime(f * 0.5, t, 0.04);
    this.filter.frequency.setTargetAtTime(500 + throttle * 1400 + (nitro ? 1500 : 0), t, 0.08);
    this.engineGain.gain.setTargetAtTime(muted ? 0 : 0.05 + throttle * 0.06, t, 0.08);
  }

  setLoops(skid: number, rain: number, wind: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.skidGain?.gain.setTargetAtTime(skid * 0.12, t, 0.06);
    this.rainGain?.gain.setTargetAtTime(rain * 0.05, t, 0.3);
    this.windGain?.gain.setTargetAtTime(wind * 0.1, t, 0.2);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number, delay = 0) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private burst(dur: number, freq: number, vol: number, type: BiquadFilterType = "lowpass") {
    if (!this.ctx || !this.master || !this.noise) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + dur);
  }

  sfx(name: "click" | "coin" | "crash" | "scrape" | "nearMiss" | "nitro" | "countdown" | "go" | "checkpoint" | "finish" | "fail" | "buy" | "cone", power = 1) {
    if (!this.ctx) return;
    switch (name) {
      case "click":
        this.tone(880, 0.06, "square", 0.04);
        break;
      case "coin":
        this.tone(1320, 0.08, "square", 0.05);
        this.tone(1760, 0.12, "square", 0.05, undefined, 0.06);
        break;
      case "buy":
        this.tone(660, 0.1, "triangle", 0.1);
        this.tone(990, 0.1, "triangle", 0.1, undefined, 0.1);
        this.tone(1320, 0.25, "triangle", 0.1, undefined, 0.2);
        break;
      case "crash":
        this.burst(0.5 + power * 0.01, 900, Math.min(0.9, 0.3 + power * 0.02));
        this.tone(90, 0.35, "sawtooth", 0.2, 40);
        break;
      case "cone":
        this.burst(0.15, 2200, 0.25, "bandpass");
        break;
      case "scrape":
        this.burst(0.25, 3500, 0.15, "highpass");
        break;
      case "nearMiss":
        this.burst(0.35, 1200, 0.3, "bandpass");
        break;
      case "nitro":
        this.burst(0.6, 600, 0.35);
        break;
      case "countdown":
        this.tone(520, 0.25, "square", 0.08);
        break;
      case "go":
        this.tone(1040, 0.5, "square", 0.09);
        break;
      case "checkpoint":
        this.tone(784, 0.12, "triangle", 0.12);
        this.tone(1175, 0.25, "triangle", 0.12, undefined, 0.12);
        break;
      case "finish":
        [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.3, "triangle", 0.12, undefined, i * 0.12));
        break;
      case "fail":
        [392, 330, 262].forEach((f, i) => this.tone(f, 0.35, "sawtooth", 0.08, undefined, i * 0.18));
        break;
    }
  }
}

export const audio = new AudioEngine();
