import type { ControlInput } from "./sim/race";

/** Held keyboard keys by physical code. */
export const keys = new Set<string>();

/** On-screen touch buttons write here. */
export const touch = { left: false, right: false, gas: false, brake: false, nitro: false, handbrake: false };

export function resetInput() {
  keys.clear();
  touch.left = touch.right = touch.gas = touch.brake = touch.nitro = touch.handbrake = false;
}

const PREVENT = new Set(["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"]);

export function attachKeyboard(onPause: () => void): () => void {
  const down = (e: KeyboardEvent) => {
    if (PREVENT.has(e.code)) e.preventDefault();
    if ((e.code === "Escape" || e.code === "KeyP") && !e.repeat) onPause();
    keys.add(e.code);
  };
  const up = (e: KeyboardEvent) => keys.delete(e.code);
  const blur = () => resetInput();
  window.addEventListener("keydown", down);
  window.addEventListener("keyup", up);
  window.addEventListener("blur", blur);
  return () => {
    window.removeEventListener("keydown", down);
    window.removeEventListener("keyup", up);
    window.removeEventListener("blur", blur);
  };
}

/** Pure mapping from key/touch state to controls; steer -1 = left, +1 = right. */
export function mapControls(k: Set<string>, t: typeof touch): ControlInput {
  const left = k.has("KeyA") || k.has("ArrowLeft") || t.left;
  const right = k.has("KeyD") || k.has("ArrowRight") || t.right;
  return {
    throttle: k.has("KeyW") || k.has("ArrowUp") || t.gas ? 1 : 0,
    brake: k.has("KeyS") || k.has("ArrowDown") || t.brake ? 1 : 0,
    steer: (right ? 1 : 0) - (left ? 1 : 0),
    handbrake: k.has("Space") || t.handbrake,
    nitro: k.has("ShiftLeft") || k.has("ShiftRight") || t.nitro,
  };
}

let padIndex: number | null = null;
if (typeof window !== "undefined") {
  window.addEventListener("gamepadconnected", (e) => {
    padIndex = (e as GamepadEvent).gamepad.index;
  });
}

/** Keyboard + touch + optional gamepad. */
export function readControls(): ControlInput {
  const c = mapControls(keys, touch);
  if (padIndex !== null && typeof navigator !== "undefined" && navigator.getGamepads) {
    const pad = navigator.getGamepads()[padIndex];
    if (pad && pad.mapping === "standard") {
      const ax = pad.axes[0] ?? 0;
      const dz = Math.abs(ax) < 0.15 ? 0 : (ax - Math.sign(ax) * 0.15) / 0.85;
      if (dz !== 0) c.steer = Math.max(-1, Math.min(1, dz));
      c.throttle = Math.max(c.throttle, pad.buttons[7]?.value ?? 0);
      c.brake = Math.max(c.brake, pad.buttons[6]?.value ?? 0);
      if (pad.buttons[0]?.pressed) c.nitro = true;
      if (pad.buttons[1]?.pressed) c.handbrake = true;
    }
  }
  return c;
}
