import { create } from "zustand";
import { persist } from "zustand/middleware";
import { CARS, getCar } from "./data/cars";
import { CAREER } from "./data/career";
import { applyResult, buyCar, defaultSave, type SaveData } from "./sim/economy";
import type { Mode, RaceResultCore } from "./sim/race";

export type Screen =
  | "loading"
  | "menu"
  | "select"
  | "garage"
  | "modes"
  | "career"
  | "settings"
  | "leaderboard"
  | "about"
  | "race";

export type Quality = "low" | "medium" | "high";
export interface Settings {
  quality: Quality;
  timeOfDay: "day" | "sunset" | "night" | "dynamic";
  weather: "clear" | "rain" | "dynamic";
  volume: number;
  camera: "chase" | "close" | "far";
  playerName: string;
  showTouch: "auto" | "on" | "off";
}

export interface RaceResult extends RaceResultCore {
  reward: number;
  newBest: boolean;
  carId: string;
  eventIndex: number;
}

export interface Session {
  mode: Mode;
  eventIndex: number;
  runId: number;
  paused: boolean;
  result: RaceResult | null;
}

interface GameStore {
  screen: Screen;
  previousScreen: Screen;
  previewCar: string;
  save: SaveData;
  settings: Settings;
  session: Session | null;
  sceneReady: boolean;
  setScreen: (s: Screen) => void;
  setPreviewCar: (id: string) => void;
  selectCar: (id: string) => void;
  buy: (id: string) => "ok" | "owned" | "coins" | "unknown";
  startRace: (mode: Mode, eventIndex?: number) => void;
  restartRace: () => void;
  setPaused: (p: boolean) => void;
  finishRace: (r: RaceResultCore) => void;
  quitToMenu: () => void;
  updateSettings: (s: Partial<Settings>) => void;
  resetProgress: () => void;
  setSceneReady: (v: boolean) => void;
}

export function defaultQuality(): Quality {
  if (typeof window === "undefined") return "medium";
  const coarse = window.matchMedia?.("(pointer: coarse)").matches;
  return coarse ? "low" : "medium";
}

let runCounter = 1;

export const useGame = create<GameStore>()(
  persist(
    (set, get) => ({
      screen: "loading",
      previousScreen: "menu",
      previewCar: "bmw-m4",
      save: defaultSave(),
      settings: {
        quality: "medium",
        timeOfDay: "dynamic",
        weather: "dynamic",
        volume: 0.7,
        camera: "chase",
        playerName: "Racer",
        showTouch: "auto",
      },
      session: null,
      sceneReady: false,
      setScreen: (screen) => set((st) => ({ screen, previousScreen: st.screen })),
      setPreviewCar: (id) => set({ previewCar: id }),
      selectCar: (id) => {
        const { save } = get();
        if (!save.unlocked.includes(id)) return;
        set({ save: { ...save, selectedCar: id }, previewCar: id });
      },
      buy: (id) => {
        const res = buyCar(get().save, CARS.find((c) => c.id === id));
        if (!res.ok) return res.reason;
        set({ save: res.save, previewCar: id });
        return "ok";
      },
      startRace: (mode, eventIndex = 0) => {
        set({
          screen: "race",
          session: { mode, eventIndex, runId: runCounter++, paused: false, result: null },
        });
      },
      restartRace: () => {
        const s = get().session;
        if (!s) return;
        set({ session: { ...s, runId: runCounter++, paused: false, result: null } });
      },
      setPaused: (paused) => {
        const s = get().session;
        if (!s || s.result) return;
        set({ session: { ...s, paused } });
      },
      finishRace: (r) => {
        const { session, save, settings } = get();
        if (!session || session.result) return;
        const ev = r.mode === "career" ? CAREER[session.eventIndex] : undefined;
        const carId = save.selectedCar;
        const applied = applyResult(save, r, {
          carId,
          playerName: settings.playerName,
          now: Date.now(),
          eventIndex: session.eventIndex,
          ...(ev ? { eventId: ev.id, careerReward: ev.reward } : {}),
        });
        set({
          save: applied.save,
          session: {
            ...session,
            paused: false,
            result: { ...r, reward: applied.reward, newBest: applied.newBest, carId, eventIndex: session.eventIndex },
          },
        });
      },
      quitToMenu: () => set({ screen: "menu", session: null }),
      updateSettings: (s) => set({ settings: { ...get().settings, ...s } }),
      resetProgress: () => set({ save: defaultSave(), previewCar: "bmw-m4" }),
      setSceneReady: (v) => set({ sceneReady: v }),
    }),
    {
      name: "usr-save-v1",
      version: 1,
      partialize: (st) => ({ save: st.save, settings: st.settings }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<GameStore>;
        const save = { ...current.save, ...(p.save ?? {}) };
        return {
          ...current,
          save,
          settings: { ...current.settings, ...(p.settings ?? {}) },
          previewCar: getCar(save.selectedCar).id,
        };
      },
    },
  ),
);

/* ---------------- HUD (high-frequency, kept out of the main store) ---------------- */

export interface Popup {
  id: number;
  text: string;
  tone: "blue" | "purple" | "gold" | "danger" | "success";
}

export interface HudState {
  speed: number;
  rpm: number;
  gear: number;
  nitro: number;
  nitroActive: boolean;
  damage: number;
  score: number;
  distance: number;
  coins: number;
  place: number;
  racers: number;
  progress: number;
  timeLeft: number;
  raceTime: number;
  combo: number;
  drifting: boolean;
  driftPoints: number;
  countdown: number;
  status: string;
  popups: Popup[];
}

export const useHud = create<HudState>()(() => ({
  speed: 0,
  rpm: 0,
  gear: 1,
  nitro: 1,
  nitroActive: false,
  damage: 0,
  score: 0,
  distance: 0,
  coins: 0,
  place: 1,
  racers: 1,
  progress: 0,
  timeLeft: 0,
  raceTime: 0,
  combo: 0,
  drifting: false,
  driftPoints: 0,
  countdown: 3,
  status: "countdown",
  popups: [],
}));

let popupId = 1;
export function pushPopup(text: string, tone: Popup["tone"]) {
  const id = popupId++;
  useHud.setState((s) => ({ popups: [...s.popups.slice(-3), { id, text, tone }] }));
  setTimeout(() => useHud.setState((s) => ({ popups: s.popups.filter((p) => p.id !== id) })), 1400);
}
