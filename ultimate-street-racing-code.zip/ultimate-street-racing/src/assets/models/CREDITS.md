# 3D model credits (all CC0 / public domain)

- supercar.glb — "Sports Car" by Quaternius — https://poly.pizza/m/Gzj704DXdr (mirror: get3dmodels.com/vehicles/sports-car) — CC0
- gtcar.glb — "Sports Car" by Quaternius — https://poly.pizza/m/1mkmFkAz5v (mirror: get3dmodels.com/vehicles/sports-car-1) — CC0
- sedan, suv, taxi, van, truck, police, delivery, cone, box — Car Kit 3.1 by Kenney — https://kenney.nl/assets/car-kit — CC0
